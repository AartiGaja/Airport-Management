﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Airport.DAO
{
   public static class Queries
    {
        public static string addFlightPlan = "insert into [Flight Plan] (Arrival_Location,Departure_Location,Arrival_Time,Departure_Time,Pilot_Id,Plane_Id) values(@arrivalLocation,@departureLocation,@arrivalTime,@departureTime,@pilotId,@planeId);";
        public static string viewFlightPlan = "select f.Flight_Id,f.Arrival_Location,f.Departure_Location,f.Arrival_Time,f.Departure_Time,p.First_Name,p.ssn,pl.Plane_name,pl.Plane_No from [Flight Plan] f join Pilot p  on f.Pilot_Id=p.Pilot_ID join Planes pl on pl.plane_Id=f.plane_Id ;";
        public static string viewFlightPlanById = "select f.Flight_Id,f.Arrival_Location,f.Departure_Location,f.Arrival_Time,f.Departure_Time,p.First_Name,p.ssn,pl.Plane_name,pl.Plane_No from [flight plan] f join Pilot p on Flight_Id=@flightId and p.pilot_Id=f.pilot_Id join Planes pl on pl.plane_Id=f.plane_Id;";
        public static string updateFlightPlan = "update [Flight Plan] set Arrival_Location=@arrivalLocation,Departure_Location=@departureLocation,Arrival_Time=@arrivalTime,Departure_Time=@departureTime,Plane_Id=@planeId where Flight_ID=@flightId;";
        public static string viewPilot = "select First_Name,Last_Name,Gender,Dob,Contact_Number,Address,SSN from Pilot where active='yes';";
        public static string viewPlane = "select Plane_Name,Plane_No,Plane_Type,Plane_Capacity,Owner_Id from Planes";
        public static string viewId = "select pilot_Id from pilot where ssn=@ssn";
        public static string viewPlaneId = "select plane_Id from planes where Plane_No=@planeNo;";
        public static string modifyUsingName = "select pilot_Id from pilot where First_Name=@firstName;";
        public static string modifyUsingPlaneNo = "select plane_Id from planes where plane_No=@planeNo;";
        public static string viewFlightPlanByPilotId = "select f.Flight_Id, f.Arrival_Location, f.Departure_Location, f.Arrival_Time, f.Departure_Time, pl.Plane_name, pl.Plane_No from [flight plan] f join Planes pl on pl.plane_Id= f.plane_Id and pilot_Id = @pilotId;";

        public static string addPlane = "insert into planes(Plane_Name,Plane_No,Plane_Type,Plane_Capacity,Owner_Id) values (@planeName,@planeNo,@planeType,@planeCapacity,@ownerId)";
        public static string getPlane = "select Plane_Id,Plane_Name,Plane_No,Plane_Type,Plane_Capacity,Owner_First_Name,Owner_Last_Name,Owner_Contact_number,Owner_Email from planes as p join[owner] as o on p.owner_id=o.owner_id";
        public static string getPlaneById = "select Plane_Id,Plane_Name,Plane_No,Plane_Type,Plane_Capacity,Owner_First_Name,Owner_Last_Name,Owner_Contact_number,Owner_Email from planes as p join[owner] as o on p.owner_id=o.owner_id and p.plane_Id=@planeId";
        public static string updatePlane = "update Planes set Plane_Name=@planeName,Plane_No=@planeNo,Plane_Type=@planeType,Plane_Capacity=@planeCapacity,Owner_Id=@ownerId where plane_Id=@planeId";

        public static string addOwner = "insert into [Owner](Owner_First_Name,Owner_Last_Name,Owner_Contact_number,Owner_Email) values (@ownerFirstName,@ownerLastName,@ownerNo,@ownerEmail)";
        public static string getOwnerById = "select Owner_First_Name,Owner_Last_Name,Owner_Contact_number,Owner_Email from Owner where Owner_Id=@OwnerId";
        public static string updateOwner = "update Owner set Owner_First_Name=@ownerFirstName,Owner_Last_Name=@ownerLastName,Owner_Contact_number=@ownerNo,Owner_Email=@ownerEmail where Owner_Id=@OwnerId";

        public static string ownerId = "select Owner_Id from Owner where Owner_First_Name=@ownerFirstName and Owner_Last_Name=@ownerLastName";
        public static string deleteOwner = "delete Owner_Id,Owner_First_Name,Owner_Last_Name,Owner_Contact_number,Owner_Email from Owner where Owner_Id=@OwnerId";
        public static string ownerName = "select Owner_First_Name,Owner_Last_Name from Owner where Owner_First_Name=@ownerFirstName and Owner_Last_Name=@ownerLastName";
        public static string ownerEmail = "select Owner_Email from Owner where Owner_First_Name=@ownerFirstName and Owner_Last_Name=@ownerLastName";

        public static string pilotIdByName = "select pilot_Id from pilot where First_name=@pilotFirstName and Last_name=@pilotLastName and ssn=@ssn;";

        public static string hangarName = "select hangar_name from hangar";
        public static string planeNo = "select plane_No from Planes where Plane_No=@planeNo";


    }
}
