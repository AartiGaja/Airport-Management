﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Airport.Model;
namespace Com.Cognizant.Airport.DAO
{
    interface IHangar
    {

        int UpdateStatus(Hangar hangar);
        int SelectId(string email);
        Hangar DisplayManager(int id);
        int EditHangarInfo(Hangar hangar);
        Hangar GetHangarById(int id);
        List<Hangar> DisplayHangar();
        int AddHangar(Hangar hangar);
        List<string> PlaneDropDown();
        List<string> HangarDropDown();
        int SelectPlaneId(string planeNo);
        int SelectHangerId(string hangarName);
        int Allot(int planeId, int hangarId);
        List<Hangar> DisplayAllotments();
    }
}
