﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Airport.Model;
namespace Com.Cognizant.Airport.DAO
{
    interface IPlaneDao
    {
        List<Plane> GetPlaneDetails();
        Plane GetPlaneDetailsById(long id);
        int AddPlaneDetails(Plane plane);
        int ModifyPlaneDetails(Plane plane);
        int CheckPlaneNo(string planeNo);
    }
}
