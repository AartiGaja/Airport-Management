﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Airport.Model;

namespace Com.Cognizant.Airport.DAO
{
    public class HangarDAO : IHangar
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        static string addHangar = "insert into hangar(Hangar_Name,Manager_Id,status,Occupancy_From_date,Occupancy_Till_date,Available_From_date,Available_Till_date)values(@hangarName,@managerId,@status,@occupancyFromDate,@occupanyTillDate,@availableFromDate,@availableTillDate)";
        static string selectId = "select Manager_ID from manager where Email_ID=@email";
        static string selectHangarName = "select Hangar_name from hangar where Hangar_Name=@hangarName";
        static string hangarDetails = "select * from hangar";
        static string managerEmail = "select Manager_Id,First_Name,Last_Name,Email_ID from [MANAGER] where Manager_Id=@managerId;";
        static string viewHangarById = "select * from hangar where Hangar_ID=@id;";
        static string updateHangar = "update Hangar set Hangar_name=@hangarName,Manager_Id=@managerId,Occupancy_From_date=@occFromDate,Occupancy_Till_date=@occTillDate,Available_From_date=@avaFromDate,Available_Till_date=@avaTillDate where Hangar_Id=@hangarId;";
        static string dropDownHangar = "select Hangar_name from [hangar] where Status='vacant'";
        static string dropDownPlane = "select plane_no from planes where plane_Id != all(select plane_Id from plane_hangar);";
        static string allotHangar = "insert into plane_hangar(plane_Id,hangar_Id) values(@plane_id,@hangar_id)";
        static string HangerId = "select hangar_id from hangar where hangar_name=@hangarname";
        static string PlaneId = "select plane_id from planes where plane_no=@planeno";
        static string allotments = "select p.plane_no,h.hangar_name from hangar h join plane_hangar ph on h.hangar_id =ph.hangar_id join planes p on p.plane_id=ph.plane_id; ";
        static string addStatus = "update hangar set status = @hangarStatus where hangar_name=@hangarName;";

        public List<Hangar> DisplayAllotments()
        {

            List<Hangar> hangarAllotList = new List<Hangar>();

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = allotments
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Hangar hangar = new Hangar();

                    hangar.PlaneDetails = new Plane();
                    hangar.HangarName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Hangar_Name")));
                    hangar.PlaneDetails.PlaneNo = Convert.ToString(dr.GetValue(dr.GetOrdinal("Plane_no")));
                    hangarAllotList.Add(hangar);
                }
            }
            if (hangarAllotList.Count == 0)
            {
                throw new EmptyException();
            }
            return hangarAllotList;

        }

        public int Allot(int planeId,int hangarId)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = allotHangar
                };
                cmd.Parameters.Add("@plane_id", SqlDbType.VarChar).Value = planeId;
                cmd.Parameters.Add("@hangar_id", SqlDbType.VarChar).Value = hangarId;
                result = cmd.ExecuteNonQuery();

            }
            return result;
        }
        public int SelectHangerId(string hangarName)
        {
            int id = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = HangerId
                };
                cmd.Parameters.Add("@hangarname", SqlDbType.VarChar).Value = hangarName;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Hangar_ID")));
                }
            }
            return id;
        }

        public int SelectPlaneId(string planeNo)
        {
            int id = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = PlaneId
                };
                cmd.Parameters.Add("@planeno", SqlDbType.VarChar).Value = planeNo;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Plane_ID")));
                }
            }
            return id;
        }
        public List<string> HangarDropDown()
        {
            List<string> hangarNameList = new List<string>();
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = dropDownHangar
                };

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Hangar hangar = new Hangar();
                    hangar.HangarName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Hangar_name")));
                    hangarNameList.Add(hangar.HangarName);
                }
            }
            if (hangarNameList.Count == 0)
            {
                throw new EmptyException();
            }
            return hangarNameList;
        }

        public List<string> PlaneDropDown()
        {
            List<string> planeNumList = new List<string>();
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = dropDownPlane
                };

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Plane plane = new Plane();
                    plane.PlaneNo = Convert.ToString(dr.GetValue(dr.GetOrdinal("Plane_no")));
                    planeNumList.Add(plane.PlaneNo);
                }
            }
            if (planeNumList.Count == 0)
            {
                throw new EmptyException();
            }
            return planeNumList;
        }


        public int AddHangar(Hangar hangar)
        {
            int result = 0;
            string hangarName = null;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = selectHangarName
                };
                cmd.Parameters.Add("@hangarName", SqlDbType.VarChar).Value = hangar.HangarName;
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (reader.GetValue(reader.GetOrdinal("Hangar_name")) != null)
                    {
                        hangarName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Hangar_name")));
                        break;
                    }
                }
            }
            if (hangarName == null)
            {
                using (SqlConnection con = new SqlConnection(callConnection))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = CommandType.Text,
                        CommandText = addHangar
                    };
                    cmd.Parameters.Add("@hangarName", SqlDbType.VarChar).Value = hangar.HangarName;
                    cmd.Parameters.Add("@managerId", SqlDbType.VarChar).Value = hangar.ManagerId;
                    cmd.Parameters.Add("@occupancyFromDate", SqlDbType.DateTime).Value = hangar.OccupanyFromDate;
                    cmd.Parameters.Add("@occupanyTillDate", SqlDbType.DateTime).Value = hangar.OccupanyTillDate;
                    cmd.Parameters.Add("@availableFromDate", SqlDbType.DateTime).Value = hangar.AvailableFromDate;
                    cmd.Parameters.Add("@availableTillDate", SqlDbType.DateTime).Value = hangar.AvailableTillDate;
                    cmd.Parameters.Add("@status", SqlDbType.VarChar).Value = hangar.Active;
                    result = cmd.ExecuteNonQuery();
                }
            }
            return result;
        }

        

        public List<Hangar> DisplayHangar()
        {

            List<Hangar> hangarList = new List<Hangar>();

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = hangarDetails
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Hangar hangar = new Hangar();
                    hangar = DisplayManager(Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Manager_Id"))));
                    hangar.HangarId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Hangar_ID")));
                    hangar.HangarName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Hangar_Name")));
                    hangar.Status = Convert.ToString(dr.GetValue(dr.GetOrdinal("Status")));
                    hangar.OccupanyFromDate = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("Occupancy_From_Date")));
                    hangar.OccupanyTillDate = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("Occupancy_Till_Date")));
                    hangar.AvailableFromDate = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("Available_From_Date")));
                    hangar.AvailableTillDate = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("Available_Till_Date")));


                    hangarList.Add(hangar);
                }
                if (hangarList.Count == 0)
                {
                    throw new EmptyException();
                }
                return hangarList;
            }

        }
       

        public Hangar GetHangarById(int id)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = viewHangarById
                };
                cmd.Parameters.Add("@id", SqlDbType.BigInt).Value = id;
                SqlDataReader reader = cmd.ExecuteReader();
                Hangar hangar = new Hangar();

                while (reader.Read())
                {
                    hangar = DisplayManager(Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Manager_Id"))));
                    hangar.HangarName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Hangar_name")));
                    hangar.OccupanyFromDate = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Occupancy_From_date")));
                    hangar.OccupanyTillDate = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Occupancy_till_date")));
                    hangar.AvailableFromDate= Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Available_from_date")));
                    hangar.AvailableTillDate = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Available_till_date")));
                }
                return hangar;
            }

        }

        public int EditHangarInfo(Hangar hangar)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = updateHangar
                };

                command.Parameters.Add("@managerId", SqlDbType.Int).Value = hangar.ManagerId;
                command.Parameters.Add("@hangarName", SqlDbType.VarChar).Value = hangar.HangarName;
                command.Parameters.Add("@hangarId", SqlDbType.Int).Value = hangar.HangarId;
                command.Parameters.Add("@occFromDate", SqlDbType.DateTime).Value = hangar.OccupanyFromDate;
                command.Parameters.Add("@occTillDate", SqlDbType.DateTime).Value = hangar.OccupanyTillDate;
                command.Parameters.Add("@avaFromDate", SqlDbType.DateTime).Value = hangar.AvailableFromDate;
                command.Parameters.Add("@avaTillDate", SqlDbType.DateTime).Value = hangar.AvailableTillDate;
                result = command.ExecuteNonQuery();
            }
            return result;
        }
        public Hangar DisplayManager(int id)
        {
            Hangar hangar = new Hangar();
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = managerEmail
                };
                cmd.Parameters.Add("@managerId", SqlDbType.Int).Value = id;
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    hangar.FirstName = Convert.ToString(reader.GetValue(reader.GetOrdinal("First_Name")));
                    hangar.LastName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Last_Name")));
                    hangar.EmailId = Convert.ToString(reader.GetValue(reader.GetOrdinal("Email_ID")));
                }
            }
            return hangar;
        }
        public int SelectId(string email)
        {
            int id = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = selectId
                };
                cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = email;
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    id = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Manager_ID")));
                }
            }
            return id;
        }

        public int UpdateStatus(Hangar hangar)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = addStatus
                };
                cmd.Parameters.Add("@hangarName", SqlDbType.VarChar).Value = hangar.HangarName;
                cmd.Parameters.Add("@hangarStatus", SqlDbType.VarChar).Value = hangar.Status;
                result = cmd.ExecuteNonQuery();
            }
            return result;
        }

        public List<string> HangarName()
        {
            Hangar hangar = new Hangar();
            List<string> hangarNameList = new List<string>(); 
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.hangarName
                };
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    hangar.HangarName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Hangar_Name")));
                    hangarNameList.Add(hangar.HangarName);
                }
            }
            if (hangarNameList.Count == 0)
            {
                throw new EmptyException();
            }
            return hangarNameList;
        }
    }
    }



