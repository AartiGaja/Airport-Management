﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Airport.Model;

namespace Com.Cognizant.Airport.DAO
{
    interface IFlightPlanDao
    {
        List<FlightPlan> getPlaneDetails();
        FlightPlan getPlaneDetailsById(int id);
        int addFlightPlanDetails(FlightPlan flightPlan);

        int modifyFlightInfo(FlightPlan plan);

        List<Pilot> getPilotDetails();
    }
}
