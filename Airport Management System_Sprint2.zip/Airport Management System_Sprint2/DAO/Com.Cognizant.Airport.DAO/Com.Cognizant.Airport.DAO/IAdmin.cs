﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Airport.Model;

namespace Com.Cognizant.Airport.DAO
{
    interface IAdmin
    {
        int AdminLogin(string adminEmail, string password);
        int UserRegistration(Admin admin);
    }
}
