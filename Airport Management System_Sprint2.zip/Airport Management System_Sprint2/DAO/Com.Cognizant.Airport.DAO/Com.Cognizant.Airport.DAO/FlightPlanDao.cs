﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Airport.Model;
using System.Data;
using System.Data.SqlClient;

namespace Com.Cognizant.Airport.DAO
{
    public class FlightPlanDao:IFlightPlanDao
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        public int addFlightPlanDetails(FlightPlan flightPlan)
        {
            int result1 = 0;
            int result2 = 0;
            int result3 = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewId
                };

                command.Parameters.Add("@ssn", SqlDbType.VarChar).Value = flightPlan.Ssn;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    flightPlan.PilotId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("pilot_Id")));
                    result1 = 1;
                }
            }

            if (result1 != 0)
            {
                using (SqlConnection con = new SqlConnection(callConnection))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand()
                    {
                        Connection = con,
                        CommandType = CommandType.Text,
                        CommandText = Queries.viewPlaneId
                    };

                    command.Parameters.Add("@planeNo", SqlDbType.VarChar).Value = flightPlan.Plane.PlaneNo;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        flightPlan.Plane.PlaneId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Plane_Id")));
                        result2 = 1;
                    }
                }
            }

            if (result2 != 0)
            {
                using (SqlConnection con = new SqlConnection(callConnection))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand()
                    {
                        Connection = con,
                        CommandType = CommandType.Text,
                        CommandText = Queries.addFlightPlan
                    };

                    command.Parameters.Add("@arrivalLocation", SqlDbType.VarChar).Value = flightPlan.ArrivalLocation;
                    command.Parameters.Add("@departureLocation", SqlDbType.VarChar).Value = flightPlan.DepartureLocation;
                    command.Parameters.Add("@arrivalTime", SqlDbType.DateTime).Value = flightPlan.ArrivalTime;
                    command.Parameters.Add("@departureTime", SqlDbType.DateTime).Value = flightPlan.DepartureTime;
                    command.Parameters.Add("@pilotId", SqlDbType.VarChar).Value = flightPlan.PilotId;
                    command.Parameters.Add("@planeId", SqlDbType.VarChar).Value = flightPlan.Plane.PlaneId;
                    result3 = command.ExecuteNonQuery();
                }
            }
            return result3;
        }



        public List<FlightPlan> getPlaneDetails()
        {
            FlightPlan flightplan = new FlightPlan();
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                List<FlightPlan> planeList = new List<FlightPlan>();
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewFlightPlan
                };
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    FlightPlan plan = new FlightPlan();
                    plan.Plane = new Plane();
                    plan.FlightId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Flight_Id")));
                    plan.ArrivalLocation = Convert.ToString(reader.GetValue(reader.GetOrdinal("Arrival_Location")));
                    plan.DepartureLocation = Convert.ToString(reader.GetValue(reader.GetOrdinal("Departure_Location")));
                    plan.ArrivalTime = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Arrival_Time")));
                    plan.DepartureTime = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Departure_Time")));
                    plan.FirstName = Convert.ToString(reader.GetValue(reader.GetOrdinal("First_Name")));
                    plan.Ssn = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("ssn")));
                    plan.Plane.PlaneName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Name")));
                    plan.Plane.PlaneNo = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_No")));
                    planeList.Add(plan);
                }
                return planeList;
            }

        }

        public FlightPlan getPlaneDetailsById(int id)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewFlightPlanById
                };
                cmd.Parameters.Add("@flightId", SqlDbType.BigInt).Value = id;
                SqlDataReader reader = cmd.ExecuteReader();
                FlightPlan plan = new FlightPlan();
                plan.Plane = new Plane();
                while (reader.Read())
                {
                    plan.FlightId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Flight_Id")));
                    plan.FirstName = Convert.ToString(reader.GetValue(reader.GetOrdinal("First_Name")));

                    plan.ArrivalLocation = Convert.ToString(reader.GetValue(reader.GetOrdinal("Arrival_Location")));
                    plan.DepartureLocation = Convert.ToString(reader.GetValue(reader.GetOrdinal("Departure_Location")));
                    plan.ArrivalTime = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Arrival_Time")));
                    plan.DepartureTime = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Departure_Time")));
                    plan.Ssn = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("ssn")));
                    plan.Plane.PlaneName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Name")));
                    plan.Plane.PlaneNo = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_No")));
                }
                return plan;
            }

        }






        public int modifyFlightInfo(FlightPlan plan)
        {
            int result1 = 0;
            int result2 = 0;

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.modifyUsingPlaneNo
                };

                command.Parameters.Add("@planeNo", SqlDbType.VarChar).Value = plan.Plane.PlaneNo;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    plan.Plane.PlaneId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("plane_Id")));
                    result1 = 1;
                }
            }

            if (result1 != 0)
            {
                using (SqlConnection con = new SqlConnection(callConnection))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand
                    {
                        Connection = con,
                        CommandType = CommandType.Text,
                        CommandText = Queries.updateFlightPlan
                    };

                    command.Parameters.Add("@arrivalLocation", SqlDbType.VarChar).Value = plan.ArrivalLocation;
                    command.Parameters.Add("@departureLocation", SqlDbType.VarChar).Value = plan.DepartureLocation;
                    command.Parameters.Add("@arrivalTime", SqlDbType.DateTime).Value = plan.ArrivalTime;
                    command.Parameters.Add("@departureTime", SqlDbType.DateTime).Value = plan.DepartureTime;
                    command.Parameters.Add("@flightId", SqlDbType.Int).Value = plan.FlightId;
                    command.Parameters.Add("@planeId", SqlDbType.Int).Value = plan.Plane.PlaneId;
                    result2 = command.ExecuteNonQuery();
                }
            }
            return result2;

        }


        public List<Pilot> getPilotDetails()
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                List<Pilot> pilotList = new List<Pilot>();
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewPilot
                };
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Pilot pilot = new Pilot();
                    pilot.FirstName = Convert.ToString(reader.GetValue(reader.GetOrdinal("First_Name")));
                    pilot.LastName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Last_Name")));
                    pilot.Gender = Convert.ToString(reader.GetValue(reader.GetOrdinal("Gender")));
                    pilot.DateOfBirth = Convert.ToString(reader.GetValue(reader.GetOrdinal("DoB")));
                    pilot.ContactNumber = Convert.ToInt64(reader.GetValue(reader.GetOrdinal("Contact_Number")));
                    pilot.Address = Convert.ToString(reader.GetValue(reader.GetOrdinal("Address")));
                    pilot.Ssn = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("SSN")));
                    pilotList.Add(pilot);
                }
                if (pilotList.Count == 0)
                {
                    throw new EmptyException();
                }
                return pilotList;
            }
        }



        public List<Plane> getPlaneDetailsList()
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                List<Plane> planeList = new List<Plane>();
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewPlane
                };
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Plane plane = new Plane();
                    plane.PlaneName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Name")));
                    plane.PlaneNo = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_No")));
                    plane.PlaneType = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Type")));
                    plane.PlaneCapacity = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Plane_capacity")));
                    plane.OwnerId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Owner_Id")));
                    planeList.Add(plane);
                }
                if (planeList.Count == 0)
                {
                    throw new EmptyException();
                }
                return planeList;
            }
        }

        public List<FlightPlan> getPlaneDetailsByPilotId(int pilotId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.viewFlightPlanByPilotId
                };
                cmd.Parameters.Add("@pilotId", SqlDbType.BigInt).Value = pilotId;
                SqlDataReader reader = cmd.ExecuteReader();
                List<FlightPlan> planList = new List<FlightPlan>();
                while (reader.Read())
                {
                    FlightPlan plan = new FlightPlan();
                    plan.Plane = new Plane();
                    plan.FlightId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Flight_Id")));
                    plan.ArrivalLocation = Convert.ToString(reader.GetValue(reader.GetOrdinal("Arrival_Location")));
                    plan.DepartureLocation = Convert.ToString(reader.GetValue(reader.GetOrdinal("Departure_Location")));
                    plan.ArrivalTime = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Arrival_Time")));
                    plan.DepartureTime = Convert.ToDateTime(reader.GetValue(reader.GetOrdinal("Departure_Time")));
                    plan.Plane.PlaneName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Name")));
                    plan.Plane.PlaneNo = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_No")));
                    planList.Add(plan);
                }
                if (planList.Count == 0)
                {
                    throw new EmptyException();
                }
                return planList;
            }
        }

    }
}
