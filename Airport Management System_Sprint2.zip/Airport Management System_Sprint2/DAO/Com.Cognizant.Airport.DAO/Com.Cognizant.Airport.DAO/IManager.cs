﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Airport.Model;

namespace Com.Cognizant.Airport.DAO
{
    interface IManager
    {
        int ManagerLogin(string adminEmail, string password);
        List<Manager> DisplayManagerList();
        int ManagerRegistration(Manager manager);
    }
}
