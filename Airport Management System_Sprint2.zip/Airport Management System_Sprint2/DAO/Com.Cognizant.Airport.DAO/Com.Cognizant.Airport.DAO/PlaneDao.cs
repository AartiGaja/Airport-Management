﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Airport.Model;

namespace Com.Cognizant.Airport.DAO
{
    public class PlaneDao : IPlaneDao
    {
        static string connection = ConnectionHandler.ConnectionVariable;
        string ownerFirstName = "";
        string ownerLastName = "";
        
        public int AddPlaneDetails(Plane plane) {
            int result1 = 0,result2=0;
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.ownerName
                };
                command.Parameters.Add("@ownerFirstName", SqlDbType.VarChar).Value = plane.OwnerFirstName;
                command.Parameters.Add("@ownerLastName", SqlDbType.VarChar).Value = plane.OwnerLastName;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if(reader.GetValue(reader.GetOrdinal("Owner_First_Name")) != null)
                    {
                        ownerFirstName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_First_Name")));
                    }
                    if (reader.GetValue(reader.GetOrdinal("Owner_Last_Name")) != null)
                    {
                        ownerLastName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_Last_Name")));
                    }
                }
            }
            if(ownerFirstName.Equals("") && ownerLastName.Equals(""))
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand()
                    {
                        Connection = con,
                        CommandType = CommandType.Text,
                        CommandText = Queries.addOwner
                    };
                    command.Parameters.Add("@ownerFirstName", SqlDbType.VarChar).Value = plane.OwnerFirstName;
                    command.Parameters.Add("@ownerLastName", SqlDbType.VarChar).Value = plane.OwnerLastName;
                    command.Parameters.Add("@ownerNo", SqlDbType.BigInt).Value = plane.OwnerMobile;
                    command.Parameters.Add("@ownerEmail", SqlDbType.VarChar).Value = plane.OwnerEmail;
                    result1 = command.ExecuteNonQuery();
                }
            }
            else
            {
                result1 = 1;
            }
            
            if(result1!=0)
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand()
                    {
                        Connection = con,
                        CommandType = CommandType.Text,
                        CommandText = Queries.ownerId
                    };
                    command.Parameters.Add("@ownerFirstName", SqlDbType.VarChar).Value = plane.OwnerFirstName;
                    command.Parameters.Add("@ownerLastName", SqlDbType.VarChar).Value = plane.OwnerLastName;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        plane.OwnerId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Owner_Id")));
                    }
                }
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    SqlCommand command = new SqlCommand()
                    {
                        Connection = con,
                        CommandType = CommandType.Text,
                        CommandText = Queries.addPlane
                    };
                    command.Parameters.Add("@planeName", SqlDbType.VarChar).Value = plane.PlaneName;
                    command.Parameters.Add("@planeNo", SqlDbType.VarChar).Value = plane.PlaneNo;
                    command.Parameters.Add("@planeType", SqlDbType.VarChar).Value = plane.PlaneType;
                    command.Parameters.Add("@planeCapacity", SqlDbType.Int).Value = plane.PlaneCapacity;
                    command.Parameters.Add("@ownerId", SqlDbType.Int).Value = plane.OwnerId;
                    result2 = command.ExecuteNonQuery();
                }

                if(result2==0)
                {
                    using (SqlConnection con = new SqlConnection(connection))
                    {
                        con.Open();
                        SqlCommand command = new SqlCommand()
                        {
                            Connection = con,
                            CommandType = CommandType.Text,
                            CommandText = Queries.deleteOwner
                        };
                        command.Parameters.Add("@ownerId", SqlDbType.VarChar).Value = plane.OwnerId;
                        command.ExecuteNonQuery();
                    }
                }
            }
            return result2;
        }

        public int CheckPlaneNo(string planeNo)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.planeNo
                };
                command.Parameters.Add("@planeNo", SqlDbType.VarChar).Value = planeNo;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if(reader.GetValue(reader.GetOrdinal("Plane_No")) != null)
                    {
                        result = 1;
                    }
                }
            }
            return result;
        }

        public List<Plane> GetPlaneDetails() {
            List<Plane> planeList = new List<Plane>();
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getPlane
                };
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Plane plane = new Plane();
                    plane.PlaneId = Convert.ToInt64(reader.GetValue(reader.GetOrdinal("Plane_Id")));
                    plane.PlaneName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Name")));
                    plane.PlaneNo = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_No")));
                    plane.PlaneType = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Type")));
                    plane.PlaneCapacity = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Plane_Capacity")));
                    plane.OwnerFirstName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_First_Name")));
                    plane.OwnerLastName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_Last_Name")));
                    plane.OwnerMobile = Convert.ToInt64(reader.GetValue(reader.GetOrdinal("Owner_Contact_Number")));
                    plane.OwnerEmail = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_Email")));
                    planeList.Add(plane);
                }
                if (planeList.Count == 0)
                {
                    throw new EmptyException();
                }
            }
            return planeList;
        }

        public Plane GetPlaneDetailsById(long id) {
            Plane plane = new Plane();
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getPlaneById
                };
                command.Parameters.Add("@planeId", SqlDbType.BigInt).Value = id;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    plane.PlaneId = Convert.ToInt64(reader.GetValue(reader.GetOrdinal("Plane_Id")));
                    plane.PlaneName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Name")));
                    plane.PlaneNo = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_No")));
                    plane.PlaneType = Convert.ToString(reader.GetValue(reader.GetOrdinal("Plane_Type")));
                    plane.PlaneCapacity = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Plane_Capacity")));
                    plane.OwnerFirstName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_First_Name")));
                    plane.OwnerLastName = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_Last_Name")));
                    plane.OwnerMobile = Convert.ToInt64(reader.GetValue(reader.GetOrdinal("Owner_Contact_Number")));
                    plane.OwnerEmail = Convert.ToString(reader.GetValue(reader.GetOrdinal("Owner_Email")));
                }        
            }
            return plane;
        }

        public int ModifyPlaneDetails(Plane plane) {
            int result1 = 0, result2 = 0;
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.ownerId
                };
                command.Parameters.Add("@ownerFirstName", SqlDbType.VarChar).Value = plane.OwnerFirstName;
                command.Parameters.Add("@ownerLastName", SqlDbType.VarChar).Value = plane.OwnerLastName;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    plane.OwnerId = Convert.ToInt32(reader.GetValue(reader.GetOrdinal("Owner_Id")));
                }
                reader.Close();
            }
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.updateOwner
                };
                command.Parameters.Add("@ownerFirstName", SqlDbType.VarChar).Value = plane.OwnerFirstName;
                command.Parameters.Add("@ownerLastName", SqlDbType.VarChar).Value = plane.OwnerLastName;
                command.Parameters.Add("@ownerNo", SqlDbType.BigInt).Value = plane.OwnerMobile;
                command.Parameters.Add("@ownerEmail", SqlDbType.VarChar).Value = plane.OwnerEmail;
                command.Parameters.Add("@ownerId", SqlDbType.BigInt).Value = plane.OwnerId;
                result1 = command.ExecuteNonQuery();
                
            }
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand()
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.updatePlane
                };
                command.Parameters.Add("@planeId", SqlDbType.BigInt).Value = plane.PlaneId;
                command.Parameters.Add("@planeName", SqlDbType.VarChar).Value = plane.PlaneName;
                command.Parameters.Add("@planeNo", SqlDbType.VarChar).Value = plane.PlaneNo;
                command.Parameters.Add("@planeType", SqlDbType.VarChar).Value = plane.PlaneType;
                command.Parameters.Add("@planeCapacity", SqlDbType.Int).Value = plane.PlaneCapacity;
                command.Parameters.Add("@ownerId", SqlDbType.BigInt).Value = plane.OwnerId;
                result2 = command.ExecuteNonQuery();
            }
            return result2;
        }
    }
}
