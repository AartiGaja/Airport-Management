﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Com.Cognizant.Airport.Model;

namespace Com.Cognizant.Airport.DAO
{
    public class ManagerInfoDAO:IManager
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        static string managerLogin = "select * from Manager";
        static string managerDetails = "select * from [Manager];";
        static string activeManagerDetails = "select * from [Manager] where active='yes';";
        static string registerManager = "insert into [Manager] (First_Name,Last_Name,Age,Gender,DoB,Contact_Number,Alt_Contact_Number,Email_ID,Password,Address,Active) values(@a_fname,@a_lname,@age,@gender,@dob,@contact_number,@alt_contact_number,@email,@password,@address,@active);";      
        static string displayFilteredManagerByID = "select * from [Manager] where Manager_ID=@managerid;";
        static string updateManager = "update [Manager] set Active=@active where Manager_ID=@managerid;";
        static string checkEmail = "select Email_ID from Manager";
        static string managerUsername = "select First_Name from manager where Email_ID=@emailid";
        public int ManagerRegistration(Manager manager)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = registerManager
                };

                cmd.Parameters.Add("@a_fname", SqlDbType.VarChar).Value = manager.FirstName;
                cmd.Parameters.Add("@a_lname", SqlDbType.VarChar).Value = manager.LastName;
                cmd.Parameters.Add("@age", SqlDbType.Int).Value = manager.Age;
                cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = manager.Gender;
                cmd.Parameters.Add("@dob", SqlDbType.VarChar).Value =  DateUtil.DateUtil.ConvertToDate(manager.DateOfBirth);
                cmd.Parameters.Add("@contact_number", SqlDbType.BigInt).Value = manager.ContactNumber;
                cmd.Parameters.Add("@alt_contact_number", SqlDbType.BigInt).Value = manager.AlternateContactNumber;
                cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = manager.EmailId;
                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = manager.Password;
                cmd.Parameters.Add("@address", SqlDbType.VarChar).Value = manager.Address;
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = "No";

                result = cmd.ExecuteNonQuery();
            }
            return result;
        }
        public List<Manager> DisplayManagerList()
        {
            List<Manager> managerList = new List<Manager>();

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = managerDetails
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Manager manger = new Manager();
                    manger.ManagerId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Manager_ID")));
                    manger.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    manger.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Last_Name")));
                    manger.Age = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Age")));
                    manger.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("Gender")));
                    manger.DateOfBirth = Convert.ToString(dr.GetValue(dr.GetOrdinal("DoB")));
                    manger.ContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Contact_Number")));
                    manger.AlternateContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Alt_Contact_Number")));
                    manger.EmailId = Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID")));
                    manger.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("Password")));
                    manger.Address = Convert.ToString(dr.GetValue(dr.GetOrdinal("Address")));
                    manger.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("Active")));

                    managerList.Add(manger);
                }
                if (managerList.Count == 0)
                {
                    throw new EmptyException();
                }
                return managerList;
            }

        }
        public int EditManagerInfo(string status, int managerId)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = updateManager
                };
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = status;
                cmd.Parameters.Add("@managerid", SqlDbType.Int).Value = managerId;
                result = cmd.ExecuteNonQuery();
            }
            return result;
        }
        public Manager DisplaySpecficUserById(int managerId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = displayFilteredManagerByID
                };

                cmd.Parameters.Add("@managerid", SqlDbType.VarChar).Value = managerId;

                SqlDataReader dr = cmd.ExecuteReader();
                Manager manager = new Manager();

                while (dr.Read())
                {
                    manager.ManagerId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Manager_ID")));
                    manager.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    manager.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Last_Name")));
                    manager.Age = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Age")));
                    manager.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("Gender")));
                    manager.DateOfBirth = Convert.ToString(dr.GetValue(dr.GetOrdinal("DoB")));
                    manager.ContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Contact_Number")));
                    manager.AlternateContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Alt_Contact_Number")));
                    manager.EmailId = Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID")));
                    manager.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("Password")));
                    manager.Address = Convert.ToString(dr.GetValue(dr.GetOrdinal("Address")));
                    manager.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("Active")));
                }
                return manager;
            }
        }
        public int CheckEmail(string emailId)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = checkEmail
                };
                SqlDataReader dr = cmd.ExecuteReader();
                Manager manager = new Manager();
                while (dr.Read())
                {
                    manager.EmailId = Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID")));
                    if (emailId.Equals(manager.EmailId))
                    {
                        result = 1;
                        break;
                    }
                }
            }
            return result;
        }
        public int ManagerLogin(string adminEmail, string password)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = managerLogin
                };
                SqlDataReader dr = cmd.ExecuteReader();
                int logResult = 0;
                while (dr.Read())
                {
                    if (Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID"))).Equals(adminEmail) &&
                      Convert.ToString(dr.GetValue(dr.GetOrdinal("Password"))).Equals(password) &&
                        Convert.ToString(dr.GetValue(dr.GetOrdinal("Active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 1;
                        break;
                    }
                    else if (Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID"))).Equals(adminEmail) &&
                       Convert.ToString(dr.GetValue(dr.GetOrdinal("Password"))).Equals(password) &&
                         Convert.ToString(dr.GetValue(dr.GetOrdinal("Active"))).Equals("no", StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 2;
                        break;
                    }
                    else
                    {
                        logResult = 3;
                    }
                }
                return logResult;
            }
        }

       

        public List<Manager> DisplayActiveManagerList()
        {

            List<Manager> managerList = new List<Manager>();

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = activeManagerDetails
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Manager manger = new Manager();
                    manger.ManagerId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Manager_ID")));
                    manger.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    manger.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Last_Name")));
                    manger.Age = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Age")));
                    manger.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("Gender")));
                    manger.DateOfBirth = Convert.ToString(dr.GetValue(dr.GetOrdinal("DoB")));
                    manger.ContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Contact_Number")));
                    manger.AlternateContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Alt_Contact_Number")));
                    manger.EmailId = Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID")));
                    manger.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("Password")));
                    manger.Address = Convert.ToString(dr.GetValue(dr.GetOrdinal("Address")));
                    manger.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("Active")));

                    managerList.Add(manger);
                }
                if (managerList.Count == 0)
                {
                    throw new EmptyException();
                }
            }
            return managerList;

        }

        public string Username(string email)
        {
            string result = "";
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = managerUsername
                };
                cmd.Parameters.Add("@emailid", SqlDbType.VarChar).Value = email;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Manager manager=new Manager();
                    manager.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    result = manager.FirstName;
                }
            }
            return result;
        }
    }
    }
   

