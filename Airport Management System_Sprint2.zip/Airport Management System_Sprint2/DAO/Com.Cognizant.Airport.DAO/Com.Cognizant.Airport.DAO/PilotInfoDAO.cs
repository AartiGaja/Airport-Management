﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Com.Cognizant.Airport.Model;

namespace Com.Cognizant.Airport.DAO
{
    public class PilotInfoDAO:IPilot
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        static string PilotLogin = "select * from Pilot";
        static string loginUsername = "select First_Name from pilot where SSN=@ssn";
        static string registerPilot = "insert into [Pilot] (First_Name,Last_Name,Gender,DoB,Contact_Number,License_Number,[Address],SSN,password,Active) values(@a_fname,@a_lname,@gender,@dob,@contact_number,@license_number,@address,@ssn,@password,@active);";
        static string pilotDetails = "select * from [Pilot];";
        static string displayFilteredPilotByID = "select * from [Pilot] where Pilot_ID=@pilotid;";
        static string updatePilot = "update [Pilot] set Active=@active where Pilot_ID=@pilotid;";
        static string checkSsn = "select SSN from Pilot";
        static string selectPilotId = "select pilot_id from Pilot where SSN=@ssn";
        public int UserId(int ssn)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = selectPilotId
                };
                cmd.Parameters.Add("@ssn", SqlDbType.Int).Value = ssn;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Pilot pilot = new Pilot();
                    pilot.PilotId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Pilot_Id")));
                    result = pilot.PilotId;
                }
            }
            return result;
        }


        public int PilotRegistration(Pilot pilot)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = registerPilot
                };

                cmd.Parameters.Add("@a_fname", SqlDbType.VarChar).Value = pilot.FirstName;
                cmd.Parameters.Add("@a_lname", SqlDbType.VarChar).Value = pilot.LastName;
                cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = pilot.Gender;
                cmd.Parameters.Add("@dob", SqlDbType.VarChar).Value = DateUtil.DateUtil.ConvertToDate(pilot.DateOfBirth);
                cmd.Parameters.Add("@contact_number", SqlDbType.BigInt).Value = pilot.ContactNumber;
                cmd.Parameters.Add("@license_number", SqlDbType.Int).Value = pilot.LicenseNumber;
                cmd.Parameters.Add("@address", SqlDbType.VarChar).Value = pilot.Address;
                cmd.Parameters.Add("@ssn", SqlDbType.Int).Value = pilot.Ssn;
                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = pilot.Password;
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = "No";

                result = cmd.ExecuteNonQuery();
            }
            return result;
        }
        public List<Pilot> DisplayPilotList()
        {
            List<Pilot> pilotList = new List<Pilot>();
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = pilotDetails
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Pilot pilot = new Pilot();
                    pilot.PilotId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Pilot_ID")));
                    pilot.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    pilot.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Last_Name")));
                    pilot.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("Gender")));
                    pilot.DateOfBirth = Convert.ToString(dr.GetValue(dr.GetOrdinal("DoB")));
                    pilot.ContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Contact_Number")));
                    pilot.LicenseNumber = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("License_Number")));
                    pilot.Address = Convert.ToString(dr.GetValue(dr.GetOrdinal("Address")));
                    pilot.Ssn = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("SSN")));
                    pilot.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("password")));
                    pilot.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("Active")));
                    pilotList.Add(pilot);
                }
                if (pilotList.Count == 0) 
                {
                    throw new EmptyException();
                }
                return pilotList;
            }

        }
        public int EditPilotInfo(string status, int pilotId)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = updatePilot
                };
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = status;
                cmd.Parameters.Add("@pilotid", SqlDbType.Int).Value = pilotId;
                result = cmd.ExecuteNonQuery();
            }
            return result;
        }
        public Pilot DisplaySpecficPilotById(int pilotId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = displayFilteredPilotByID
                };

                cmd.Parameters.Add("@pilotid", SqlDbType.VarChar).Value = pilotId;

                SqlDataReader dr = cmd.ExecuteReader();
                Pilot pilot = new Pilot();

                while (dr.Read())
                {
                    pilot.PilotId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("Pilot_ID")));
                    pilot.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    pilot.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("Last_Name")));
                    pilot.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("Gender")));
                    pilot.DateOfBirth = Convert.ToString(dr.GetValue(dr.GetOrdinal("DoB")));
                    pilot.ContactNumber = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("Contact_Number")));
                    pilot.LicenseNumber = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("License_Number")));
                    pilot.Address = Convert.ToString(dr.GetValue(dr.GetOrdinal("Address")));
                    pilot.Ssn = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("SSN")));
                    pilot.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("password")));
                    pilot.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("Active")));
                }
                return pilot;
            }
        }
        public int CheckSSn(int ssn)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = checkSsn
                };
                SqlDataReader dr = cmd.ExecuteReader();
                Pilot pilot = new Pilot();
                while (dr.Read())
                {
                    pilot.Ssn = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("SSN")));
                    if (ssn == pilot.Ssn)
                    {
                        result = 1;
                        break;
                    }
                }
            }
            return result;
        }
        public string Username(int ssn)
        {
            string result = "";
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = loginUsername
                };
                cmd.Parameters.Add("@ssn", SqlDbType.Int).Value = ssn;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Pilot pilot = new Pilot();
                    pilot.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    result = pilot.FirstName;
                }
            }
            return result;
        }
        public int pilotLogin(int SSN, string password)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = PilotLogin
                };
                SqlDataReader dr = cmd.ExecuteReader();
                int logResult = 0;
                while (dr.Read())
                {
                    if (Convert.ToInt32(dr.GetValue(dr.GetOrdinal("SSN"))).Equals(SSN) &&
                      Convert.ToString(dr.GetValue(dr.GetOrdinal("password"))).Equals(password) &&
                        Convert.ToString(dr.GetValue(dr.GetOrdinal("Active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 1;
                        break;
                    }
                    else if (Convert.ToInt32(dr.GetValue(dr.GetOrdinal("SSN"))).Equals(SSN) &&
                       Convert.ToString(dr.GetValue(dr.GetOrdinal("password"))).Equals(password) &&
                         Convert.ToString(dr.GetValue(dr.GetOrdinal("Active"))).Equals("no", StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 2;
                        break;
                    }
                    else
                    {
                        logResult = 3;
                    }
                }
                return logResult;
            }
        }

        
    }
}
