﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Com.Cognizant.Airport.DAO
{
    public class ConnectionHandler
    {
        static string convariable = ConfigurationManager.ConnectionStrings["db_connection"].ToString();
        public static string ConnectionVariable
        {
            get
            {
                return convariable;
            }
        }
    }
}
