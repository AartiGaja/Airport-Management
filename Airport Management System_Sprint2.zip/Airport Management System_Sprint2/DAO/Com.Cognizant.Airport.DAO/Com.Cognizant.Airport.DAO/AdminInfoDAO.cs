﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Com.Cognizant.Airport.Model;
using DateUtil;

namespace Com.Cognizant.Airport.DAO
{
    public class AdminInfoDAO : IAdmin
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        
        static string loginAdmin = "select * from admin";
        static string loginUsername = "select First_Name from admin where Email_ID=@emailid";
        static string registerAdmin = "insert into [Admin] (First_Name,Last_Name,Age,Gender,DoB,Contact_Number,Alt_Contact_Number,Email_ID,Password) values(@a_fname,@a_lname,@age,@gender,@dob,@contact_number,@alt_contact_number,@email,@password);";
        static string checkEmail = "select Email_ID from [Admin]";


        public int UserRegistration(Admin admin)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = registerAdmin
                };

                cmd.Parameters.Add("@a_fname", SqlDbType.VarChar).Value = admin.FirstName;
                cmd.Parameters.Add("@a_lname", SqlDbType.VarChar).Value = admin.LastName;
                cmd.Parameters.Add("@age", SqlDbType.Int).Value = admin.Age;
                cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = admin.Gender;
                cmd.Parameters.Add("@dob", SqlDbType.Date).Value = DateUtil.DateUtil.ConvertToDate(admin.DateOfBirth);
                cmd.Parameters.Add("@contact_number", SqlDbType.BigInt).Value = admin.ContactNumber;
                cmd.Parameters.Add("@alt_contact_number", SqlDbType.BigInt).Value = admin.AlternateContactNumber;
                cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = admin.EmailId;
                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = admin.Password;

                result = cmd.ExecuteNonQuery();
            }
            return result;
        }
        public int CheckEmail(string emailId)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = checkEmail
                };
                SqlDataReader dr = cmd.ExecuteReader();
                Admin admin = new Admin();
                while (dr.Read())
                {
                    admin.EmailId = Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID")));
                    if (emailId.Equals(admin.EmailId))
                    {
                        result = 1;
                        break;
                    }
                }
            }
            return result;
        }

        public string Username(string email)
        {
            string result = "";
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = loginUsername
                };
                cmd.Parameters.Add("@emailid", SqlDbType.VarChar).Value = email;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Admin admin = new Admin();
                    admin.FirstName=Convert.ToString(dr.GetValue(dr.GetOrdinal("First_Name")));
                    result = admin.FirstName;
                }
            }
            return result;
        }
        public int AdminLogin(string adminEmail, string password)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = loginAdmin
                };
                SqlDataReader dr = cmd.ExecuteReader();
                int logResult = 0;
                while (dr.Read())
                {
                    if (Convert.ToString(dr.GetValue(dr.GetOrdinal("Email_ID"))).Equals(adminEmail) &&
                      Convert.ToString(dr.GetValue(dr.GetOrdinal("Password"))).Equals(password))
                    {
                        logResult = 1;
                        break;
                    }
                }
                return logResult;
            }
        }
    }
}
