﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateUtil
{
   public class DateUtil1
    {
        public static DateTime ConvertToDate(string inputDate)
        {
            DateTime dt = DateTime.ParseExact(inputDate, "yyyy'-'MM'-'dd'T'HH:mm", CultureInfo.InvariantCulture);
            return dt;
        }
       
    }
}
