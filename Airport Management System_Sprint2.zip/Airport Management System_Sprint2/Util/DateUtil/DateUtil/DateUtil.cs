﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
namespace DateUtil
{
    public class DateUtil
    {
         public static DateTime ConvertToDate(string inputDate) {
            DateTime dt = DateTime.ParseExact(inputDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            return dt;
        }
    }
}
