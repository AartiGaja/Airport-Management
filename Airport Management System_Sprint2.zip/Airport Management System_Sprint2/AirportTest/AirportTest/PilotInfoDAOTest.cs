﻿using System;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AirportTest
{
    [TestClass]
    public class PilotInfoDAOTest
    {
        [TestMethod]
        public void TestPilotLogin()
        {
            PilotInfoDAO pilotLogin = new PilotInfoDAO();
            int result = pilotLogin.PilotLogin(1, "753");
            Assert.AreEqual(1, result);                                         
        }

        [TestMethod]
        public void TestPilotLoginInactive()
        {
            PilotInfoDAO pilotLogin = new PilotInfoDAO();
            int result = pilotLogin.PilotLogin(2, "523");
            Assert.AreEqual(2, result);
        }
        [TestMethod]
        public void TestPilotLoginInvalid()
        {
            PilotInfoDAO pilotLogin = new PilotInfoDAO();
            int result = pilotLogin.PilotLogin(2, "753");
            Assert.AreEqual(3, result);
        }
    }
}
