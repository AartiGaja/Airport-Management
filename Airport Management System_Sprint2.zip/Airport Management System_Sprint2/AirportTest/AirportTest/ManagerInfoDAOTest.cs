﻿using System;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AirportTest
{
    [TestClass]
    public class ManagerInfoDAOTest
    {
        [TestMethod]
        public void TestManagerLogin()
        {
            ManagerInfoDAO managerLogin = new ManagerInfoDAO();
            int result = managerLogin.ManagerLogin(1, "159");
            Assert.AreEqual(1, result);
        }
        [TestMethod]
        public void TestManagerLoginInactive()
        {
            ManagerInfoDAO managerLogin = new ManagerInfoDAO();
            int result = managerLogin.ManagerLogin(2, "123");
            Assert.AreEqual(2, result);
        }
        [TestMethod]
        public void TestManagerLoginInvalid()
        {
            ManagerInfoDAO managerLogin = new ManagerInfoDAO();
            int result = managerLogin.ManagerLogin(2, "159");
            Assert.AreEqual(3, result);
        }
    }
}
