﻿using System;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AirportTest
{
    [TestClass]
    public class AdminInfoDAOTest
    {
        [TestMethod]
        public void TestAdminLogin()
        {
          
            AdminInfoDAO adminLogin = new AdminInfoDAO();
            int result = adminLogin.AdminLogin(1, "159");
            Assert.AreEqual(1, result);
        }
        [TestMethod]
        public void TestAdminLoginInvalid()
        {

            AdminInfoDAO adminLogin = new AdminInfoDAO();
            int result = adminLogin.AdminLogin(1, "753");
            Assert.AreEqual(0, result);
        }


    }
}
