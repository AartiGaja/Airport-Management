﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Airport.Model
{
    public class Plane
    {
        private long planeId;
        private string planeNo;
        private string planeName;
        private string planeType;
        private int planeCapacity;
        private string ownerFirstName;
        private string ownerLastName;
        private long ownerMobile;
        private string ownerEmail;
        private long ownerId;

        public Plane()
        {

        }

        public Plane(long planeId, string planeNo, string planeName, string planeType, int planeCapacity, string ownerFirstName, string ownerLastName, long ownerMobile, string ownerEmail, long ownerId)
        {
            this.planeId = planeId;
            this.planeNo = planeNo;
            this.planeName = planeName;
            this.planeType = planeType;
            this.planeCapacity = planeCapacity;
            this.ownerFirstName = ownerFirstName;
            this.ownerLastName = ownerLastName;
            this.ownerMobile = ownerMobile;
            this.ownerEmail = ownerEmail;
            this.ownerId = ownerId;
        }

        public string PlaneName
        {
            get
            {
                return planeName;
            }
            set
            {
                planeName = value;
            }
        }

        public string PlaneType
        {
            get
            {
                return planeType;
            }
            set
            {
                planeType = value;
            }
        }

        public int PlaneCapacity
        {
            get
            {
                return planeCapacity;
            }
            set
            {
                planeCapacity = value;
            }
        }

        public string OwnerFirstName
        {
            get
            {
                return ownerFirstName;
            }
            set
            {
                ownerFirstName = value;
            }
        }

        public string OwnerLastName
        {
            get
            {
                return ownerLastName;
            }
            set
            {
                ownerLastName = value;
            }
        }

        public long OwnerMobile
        {
            get
            {
                return ownerMobile;
            }
            set
            {
                ownerMobile = value;
            }
        }

        public string OwnerEmail
        {
            get
            {
                return ownerEmail;
            }
            set
            {
                ownerEmail = value;
            }
        }

        public long PlaneId
        {
            get
            {
                return planeId;
            }
            set
            {
                planeId = value;
            }
        }

        public long OwnerId
        {
            get
            {
                return ownerId;
            }
            set
            {
                ownerId = value;
            }
        }

        public string PlaneNo
        {
            get
            {
                return planeNo;
            }
            set
            {
                planeNo = value;
            }
        }
    }
}
