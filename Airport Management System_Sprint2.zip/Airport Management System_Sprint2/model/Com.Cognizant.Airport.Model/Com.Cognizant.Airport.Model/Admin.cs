﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Airport.Model
{
    public class Admin
    {
        private string adminId;
        private string firstName;
        private string lastName;
        private string age;
        private string gender;
        private string dateOfBirth;
        private long contactNumber;
        private long alternateContactNumber;
        private string emailId;
        private string password;
        public Admin()
        {

        }

        public Admin(string adminId, string firstName, string lastName, string age, string gender, string dateOfBirth, long contactNumber, long alternateContactNumber, string emailId, string password)
        {
            this.AdminId = adminId;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Age = age;
            this.Gender = gender;
            this.DateOfBirth = dateOfBirth;
            this.ContactNumber = contactNumber;
            this.AlternateContactNumber = alternateContactNumber;
            this.EmailId = emailId;
            this.Password = password;
        }
        public string AdminId
        {
            get
            {
                return adminId;
            }

            set
            {
                adminId = value;
            }
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public string Age
        {
            get
            {
                return age;
            }

            set
            {
                age = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public string DateOfBirth
        {
            get
            {
                return dateOfBirth;
            }

            set
            {
                dateOfBirth = value;
            }
        }

        public long ContactNumber
        {
            get
            {
                return contactNumber;
            }

            set
            {
                contactNumber = value;
            }
        }

        public long AlternateContactNumber
        {
            get
            {
                return alternateContactNumber;
            }

            set
            {
                alternateContactNumber = value;
            }
        }

        public string EmailId
        {
            get
            {
                return emailId;
            }

            set
            {
                emailId = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

    }
}
