﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Airport.Model
{
    public class Hangar:Manager
    
    {
        private int hangarId;
        private string hangarName;
        private string status;
        private DateTime occupanyFromDate;
        private DateTime occupanyTillDate;
        private DateTime availableFromDate;
        private DateTime availableTillDate;
        private Manager managerDetails;
        private Plane planeDetails;

        public int HangarId
        {
            get
            {
                return hangarId;
            }

            set
            {
                hangarId = value;
            }
        }

        public string HangarName
        {
            get
            {
                return hangarName;
            }

            set
            {
                hangarName = value;
            }
        }

        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public DateTime OccupanyFromDate
        {
            get
            {
                return occupanyFromDate;
            }

            set
            {
                occupanyFromDate = value;
            }
        }

        public DateTime OccupanyTillDate
        {
            get
            {
                return occupanyTillDate;
            }

            set
            {
                occupanyTillDate = value;
            }
        }

        public DateTime AvailableFromDate
        {
            get
            {
                return availableFromDate;
            }

            set
            {
                availableFromDate = value;
            }
        }

        public DateTime AvailableTillDate
        {
            get
            {
                return availableTillDate;
            }

            set
            {
                availableTillDate = value;
            }
        }

        public Manager ManagerDetails
        {
            get
            {
                return managerDetails;
            }

            set
            {
                managerDetails = value;
            }
        }

        public Plane PlaneDetails
        {
            get
            {
                return planeDetails;
            }

            set
            {
                planeDetails = value;
            }
        }

        public Hangar(int hangarId, string hangarName, string status, DateTime occupanyFromDate, DateTime occupanyTillDate, DateTime availableFromDate, DateTime availableTillDate, Manager managerDetails, Plane planeDetails)
        {
            this.HangarId = hangarId;
            this.HangarName = hangarName;
            this.Status = status;
            this.OccupanyFromDate = occupanyFromDate;
            this.OccupanyTillDate = occupanyTillDate;
            this.AvailableFromDate = availableFromDate;
            this.AvailableTillDate = availableTillDate;
            this.ManagerDetails = managerDetails;
            this.PlaneDetails = planeDetails;
        }
        public Hangar()
        {

        }

      
    }
   
}
