﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Airport.Model
{
    public class Pilot
    {

        private int pilotId;
        private string firstName;
        private string lastName;
        private string gender;
        private string dateOfBirth;
        private long contactNumber;
        private int licenseNumber;
        private string address;
        private int ssn;
        private string password;
        private string active;


        public Pilot()
        {

        }

        public Pilot(int pilotId, string firstName, string lastName, string gender, string dateOfBirth, long contactNumber, int licenseNumber, string address, int ssn, string password, string active)
        {
            this.PilotId = pilotId;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Gender = gender;
            this.DateOfBirth = dateOfBirth;
            this.ContactNumber = contactNumber;
            this.LicenseNumber = licenseNumber;
            this.Address = address;
            this.Ssn = ssn;
            this.Password = password;
            this.Active = active;
        }
        public int PilotId
        {
            get
            {
                return pilotId;
            }

            set
            {
                pilotId = value;
            }
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public string DateOfBirth
        {
            get
            {
                return dateOfBirth;
            }

            set
            {
                dateOfBirth = value;
            }
        }

        public long ContactNumber
        {
            get
            {
                return contactNumber;
            }

            set
            {
                contactNumber = value;
            }
        }

        public int LicenseNumber
        {
            get
            {
                return licenseNumber;
            }

            set
            {
                licenseNumber = value;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public int Ssn
        {
            get
            {
                return ssn;
            }

            set
            {
                ssn = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Active
        {
            get
            {
                return active;
            }

            set
            {
                active = value;
            }
        }


    }
}
