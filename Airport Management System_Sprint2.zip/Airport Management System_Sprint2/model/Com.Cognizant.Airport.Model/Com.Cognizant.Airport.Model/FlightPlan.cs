﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Airport.Model
{
    public class FlightPlan : Pilot
    {
        private int flightId;
        private string arrivalLocation;
        private string departureLocation;
        private DateTime arrivalTime;
        private DateTime departureTime;
        private Plane plane;
        public FlightPlan()
        {

        }

        public FlightPlan(int flightId, string arrivalLocation, string departureLocation, DateTime arrivalTime, DateTime departureTime, Plane plane)
        {
            this.flightId = flightId;
            this.arrivalLocation = arrivalLocation;
            this.departureLocation = departureLocation;
            this.arrivalTime = arrivalTime;
            this.departureTime = departureTime;
            this.Plane = plane;
        }

        public int FlightId
        {
            get
            {
                return flightId;
            }

            set
            {
                flightId = value;
            }
        }

        public string ArrivalLocation
        {
            get
            {
                return arrivalLocation;
            }

            set
            {
                arrivalLocation = value;
            }
        }

        public string DepartureLocation
        {
            get
            {
                return departureLocation;
            }

            set
            {
                departureLocation = value;
            }
        }

        public DateTime ArrivalTime
        {
            get
            {
                return arrivalTime;
            }

            set
            {
                arrivalTime = value;
            }
        }

        public DateTime DepartureTime
        {
            get
            {
                return departureTime;
            }

            set
            {
                departureTime = value;
            }
        }

        public Plane Plane
        {
            get
            {
                return plane;
            }

            set
            {
                plane = value;
            }
        }
    }
}
