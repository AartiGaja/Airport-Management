﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Airport.Model
{
    public class Manager
    {
        private int managerId;
        private string firstName;
        private string lastName;
        private int age;
        private string gender;
        private string dateOfBirth;
        private long contactNumber;
        private long alternateContactNumber;
        private string emailId;
        private string password;
        private string address;
        private string active;
        public Manager()
        {

        }

        public Manager(int managerId, string firstName, string lastName, int age, string gender, string dateOfBirth, long contactNumber, long alternateContactNumber, string emailId, string password, string address, string active)
        {
            this.ManagerId = managerId;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Age = age;
            this.Gender = gender;
            this.DateOfBirth = dateOfBirth;
            this.ContactNumber = contactNumber;
            this.AlternateContactNumber = alternateContactNumber;
            this.EmailId = emailId;
            this.Password = password;
            this.Address = address;
            this.Active = active;
        }
        public int ManagerId
        {
            get
            {
                return managerId;
            }

            set
            {
                managerId = value;
            }
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public int Age
        {
            get
            {
                return age;
            }

            set
            {
                age = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public string DateOfBirth
        {
            get
            {
                return dateOfBirth;
            }

            set
            {
                dateOfBirth = value;
            }
        }

        public long ContactNumber
        {
            get
            {
                return contactNumber;
            }

            set
            {
                contactNumber = value;
            }
        }

        public long AlternateContactNumber
        {
            get
            {
                return alternateContactNumber;
            }

            set
            {
                alternateContactNumber = value;
            }
        }

        public string EmailId
        {
            get
            {
                return emailId;
            }

            set
            {
                emailId = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public string Active
        {
            get
            {
                return active;
            }

            set
            {
                active = value;
            }
        }
    }
}
