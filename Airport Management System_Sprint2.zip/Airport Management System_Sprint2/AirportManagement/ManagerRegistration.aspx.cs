﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;

public partial class _Default : System.Web.UI.Page
{

    ManagerInfoDAO md = new ManagerInfoDAO();
    Manager manager = new Manager();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            Response.Redirect("Admin.aspx");
        }
        if (Session["managerId"] != null)
        {
            Response.Redirect("Manager.aspx");
        }
        if (Session["pilotId"] != null)
        {
            Response.Redirect("Pilot.aspx");
        }
    }
    protected void Manager_Submit(object sender, EventArgs e)
    {
        DateTime dt;
        if (!(DateTime.TryParse(TextBox4.Text, out dt)))
        {
            lblDOB0.Text = "Date format should be dd/MM/yyyy";
        }
        else
        {
            lblDOB0.Text = "";
            if (DateTime.Parse(TextBox4.Text) <= DateTime.Now)
            {
                lblDOB.Text = "";
                TimeSpan span = DateTime.Now - DateTime.Parse(TextBox4.Text);
                int age = (DateTime.MinValue + span).Year - 1;
                manager.Age = age;

                int result1 = 0;
                manager.FirstName = TextBox1.Text;
                manager.LastName = TextBox8.Text;
                if (Radio_Male.Checked == true)
                {
                    Radio_female.Checked = false;
                    manager.Gender = "Male";
                }
                else
                {
                    Radio_Male.Checked = false;
                    manager.Gender = "Female";
                }
                manager.DateOfBirth = TextBox4.Text;
                manager.ContactNumber = long.Parse(TextBox5.Text);
                manager.AlternateContactNumber = long.Parse(TextBox9.Text);
                manager.EmailId = TextBox6.Text;
                manager.Password = TextBox7.Text;
                manager.Address = TextBox10.Text;
                int resultSsn = md.CheckEmail(manager.EmailId);
                if (resultSsn == 1)
                {
                    checkEmail.Text = "*Email Id already exits";

                }
                else
                {
                    checkEmail.Text = "";
                    result1++;
                }
                if (Radio_Male.Checked == true || Radio_female.Checked == true)
                {
                    lblGender.Text = "";
                    result1++;
                }
                if (DateUtil.DateUtil.ConvertToDate(TextBox4.Text) < System.DateTime.Now)
                {
                    lblDOB.Text = "";
                    result1++;
                }
                if (result1 == 3)
                {
                    int result = md.ManagerRegistration(manager);
                    if (result > 0)
                    {
                        Session["EmailID"] = TextBox6.Text;
                        Response.Redirect("RegistrationSuccessInfo.aspx");
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
                if (Radio_Male.Checked == false && Radio_female.Checked == false)
                {
                    lblGender.Text = "*Select a Gender";
                }
                
            }
            else
            {
                lblDOB.Text = "*Select Valid DOB";
            }
        }
    }
        

    protected void Radio_Male_CheckedChanged(object sender, EventArgs e)
    {
        if (Radio_Male.Checked == true)
        {
            Radio_female.Checked = false;
            lblGender.Text = "";
        }
    }

    protected void Radio_female_CheckedChanged(object sender, EventArgs e)
    {
        if (Radio_female.Checked == true)
        {
            Radio_Male.Checked = false;
            lblGender.Text = "";
        }
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Initial Selection.aspx");

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ManagerRegistration.aspx");
    }

    protected void TextBox9_TextChanged(object sender, EventArgs e)
    {
        if(TextBox9.Text == TextBox5.Text)
        {
            lblAlternateContactNumber.Text = "*Alternate Contact Number should be Different";
        }
        else
        {
            lblAlternateContactNumber.Text = "";
        }
    }
}