﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
using DateUtil;


public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }


        if (!IsPostBack)
        {
            try
            {
                FlightPlan plan = new FlightPlan();
                Pilot pilot = new Pilot();
                plan.Plane = new Plane();
                FlightPlanDao flightDao = new FlightPlanDao();
                List<FlightPlan> flightList = flightDao.getPlaneDetails();
                flightPlanGrid.DataSource = flightList;
                flightPlanGrid.DataBind();
            }
            
            catch (EmptyException)
            {
                Response.Redirect("EmptyPlane.aspx");
            }
        }


    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }
}