﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            ddlHangar.Items.Add("Select");
            ddlHangar.Items.Add("Add Hangar");
            ddlHangar.Items.Add("View Hangar");
            ddlView.Items.Add("Select");
            ddlView.Items.Add("Manager");
            ddlView.Items.Add("Pilot");
            ddlPlane.Items.Add("Select");
            ddlPlane.Items.Add("Add Plane");
            ddlPlane.Items.Add("View Planes");
            ddlSchedule.Items.Add("Select");
            ddlSchedule.Items.Add("Add Schedule");
            ddlSchedule.Items.Add("View Schedule");
            lblErrorGetDetails.Visible = false;
            lblErrorGetPlane.Visible = false;
            lblErrorGetSchedule.Visible = false;
            lblErrorGetHangar.Visible = false;
        }
    }

    protected void btnGetDetails_Click(object sender, EventArgs e)
    {
        if (ddlView.SelectedItem.Text == "Select")
        {
            lblErrorGetDetails.Visible=true;
        }
        if (ddlView.SelectedItem.Text == "Manager")
        {
            Response.Redirect("ManagerDetails.aspx");
        }
        if (ddlView.SelectedItem.Text == "Pilot")
        {
            Response.Redirect("PilotDetails.aspx");
        }
    }

    protected void btnPlane_Click(object sender, EventArgs e)
    {
        if (ddlPlane.SelectedItem.Text == "Select")
        {
            lblErrorGetPlane.Visible=true;
        }
        if (ddlPlane.SelectedItem.Text == "Add Plane")
        {
            Response.Redirect("AddPlane.aspx");
        }
        if (ddlPlane.SelectedItem.Text == "View Planes")
        {
            Response.Redirect("DisplayPlane.aspx");
        }
    }

    protected void btnGetSchedule_Click(object sender, EventArgs e)
    {
        if(ddlSchedule.SelectedItem.Text== "Select")
        {
            lblErrorGetSchedule.Visible = true;
        }

        if (ddlSchedule.SelectedItem.Text == "Add Schedule")
        {
            Response.Redirect("AddFlightPlanAdmin.aspx");
        }
        if (ddlSchedule.SelectedItem.Text == "View Schedule")
        {
            Response.Redirect("ViewScheduleAdmin.aspx");
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnGetHangar_Click(object sender, EventArgs e)
    {
        if (ddlHangar.SelectedItem.Text == "Select")
        {
            lblErrorGetHangar.Visible = true;
        }

        if (ddlHangar.SelectedItem.Text == "Add Hangar")
        {
            Response.Redirect("AddHangar.aspx");
        }
        if (ddlHangar.SelectedItem.Text == "View Hangar")
        {
            Response.Redirect("ViewHangar.aspx");
        }
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");
    }
}