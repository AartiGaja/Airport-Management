﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["pilotId"] != null)
        {
            lblWelcome.Text = Session["pilotId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }


        try
        {
            txtPilot.Text = Session["Pilot_Id"].ToString();
            FlightPlan plan = new FlightPlan();
            Pilot pilot = new Pilot();
            plan.Plane = new Plane();
            FlightPlanDao flightDao = new FlightPlanDao();
            List<FlightPlan> flightList = flightDao.getPlaneDetailsByPilotId(int.Parse(txtPilot.Text));
            flightPlanGrid.DataSource = flightList;
            flightPlanGrid.DataBind();
        }
        
        catch (EmptyException)
        {
            Response.Write("<script>alert('No schedule have assigned to you');window.location.href='Pilot.aspx'</script");
        }

    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["pilotId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void editFlightPlan(object sender, GridViewEditEventArgs e)
    {
        GridViewRow row = flightPlanGrid.Rows[e.NewEditIndex];
        string flightId = row.Cells[0].Text;
        Response.Redirect("EditFlightPlanStatus.aspx?FlightId=" + flightId);

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Pilot.aspx");

    }
}