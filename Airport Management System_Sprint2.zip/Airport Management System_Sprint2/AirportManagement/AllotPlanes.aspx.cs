﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;

public partial class _Default : System.Web.UI.Page
{
    HangarDAO hangarDao = new HangarDAO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["managerId"] != null)
        {
            lblWelcome.Text = Session["managerId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }

        if (!IsPostBack)
        {
            List<string> hangerName = hangarDao.HangarDropDown();
            foreach(string str in hangerName)
            {
                ddlHangar.Items.Add(str);
            }
            List<string> planeNo = hangarDao.PlaneDropDown();
            foreach (string str in planeNo)
            {
                ddlPlane.Items.Add(str);
            }
        }
    }

    protected void btnAllot_Click(object sender, EventArgs e)
    {
        HangarDAO hangarDao = new HangarDAO();
        int hangerId = hangarDao.SelectHangerId(ddlHangar.SelectedItem.Text);
        int planeId= hangarDao.SelectPlaneId(ddlPlane.SelectedItem.Text);
        hangarDao.Allot(planeId, hangerId);
        Response.Write("<script>alert('Alloted successfully');window.location.href='ViewAllotments.aspx'</script>");
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["managerId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Manager.aspx");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Manager.aspx");
    }


}