﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            ddlPlaneType.Items.Add("Select Type");
            ddlPlaneType.Items.Add("Light Jets");
            ddlPlaneType.Items.Add("Mid Size Jets");
            ddlPlaneType.Items.Add("Heavy Jets");
            ddlPlaneType.Items.Add("Regional Jets");
            ddlPlaneType.Items.Add("Narrow Body Aircraft");
            ddlPlaneCapacity.Items.Add("Select Capacity");
            for (int i = 200; i <= 1000; i = i + 100)
            {
                ddlPlaneCapacity.Items.Add(i.ToString());
            }
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }
    protected void btnAddPlane_Click(object sender, EventArgs e)
    {
        Plane plane = new Plane();
        plane.PlaneName = txtName.Text;
        plane.PlaneNo = txtNo.Text;
        plane.PlaneType = ddlPlaneType.SelectedItem.Text;
        plane.PlaneCapacity = int.Parse(ddlPlaneCapacity.SelectedItem.Text);
        plane.OwnerFirstName = txtOwnweFirstName.Text;
        plane.OwnerLastName = txtOwnweLastName.Text;
        plane.OwnerMobile = long.Parse(txtOwnerNo.Text);
        plane.OwnerEmail = txtOwnerEmail.Text;
        PlaneDao planeDao = new PlaneDao();
        if (planeDao.CheckPlaneNo(plane.PlaneNo) == 1)
        {
            lblNo.Text = "Flight Number already exists";
        }
        else
        {
            int result = planeDao.AddPlaneDetails(plane);
            if (result > 0)
            {

                Response.Redirect("AddSuccess.aspx");
            }
            else
            {
                Response.Write("<script>alert('Plane Details not added successfully....Try again');window.location.href='AddPlane.aspx'</script>");
            }
        }
        
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }

}