﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;

public partial class Default2 : System.Web.UI.Page
{
    Pilot pilot = new Pilot();
    PilotInfoDAO pilotDao = new PilotInfoDAO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            if (Session["pilotId1"] == null)
            {
                Response.Redirect("Admin.aspx");
            }
            else
            {
                int pilotId = int.Parse(Session["pilotId1"].ToString());
                Label1.Text = pilotId.ToString();
                pilot = pilotDao.DisplaySpecficPilotById(pilotId);
                lblFirstName.Text = pilot.FirstName;
                lblLastName.Text = pilot.LastName;
                lblGender.Text = pilot.Gender;
                lblDateofBirth.Text = pilot.DateOfBirth;
                lblContactNumber.Text = pilot.ContactNumber.ToString();
                lblLicenseNumber.Text = pilot.LicenseNumber.ToString();
                lblAddress.Text = pilot.Address;
                lblSSN.Text = pilot.Ssn.ToString();
                if (pilot.Active.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }
            }
        }
    }

    protected void btnUpdatePilot_Click(object sender, EventArgs e)
    {
        int pilotId = int.Parse(Session["pilotId1"].ToString());
        Label1.Text = pilotId.ToString();
        if (chkActive.Checked == true)
        {
            pilot.Active = "Yes";
        }
        else if (chkActive.Checked == false)
        {
            pilot.Active = "No";
        }
        string active = pilot.Active;
        pilotDao.EditPilotInfo(active, pilotId);
        Response.Write("<script>alert('Update Successfull');window.location.href='PilotDetails.aspx'</script");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("PilotDetails.aspx");
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }
}