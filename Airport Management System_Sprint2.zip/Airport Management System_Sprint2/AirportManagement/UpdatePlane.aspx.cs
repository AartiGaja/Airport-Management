﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
public partial class Default2 : System.Web.UI.Page
{
    Plane plane = new Plane();
    PlaneDao dao = new PlaneDao();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            if (Session["planeId"] == null)
            {
                Response.Redirect("Admin.aspx");
            }
            else
            {
                ddlPlaneType.Items.Add("Select");
                ddlPlaneType.Items.Add("Light Jets");
                ddlPlaneType.Items.Add("Mid Size Jets");
                ddlPlaneType.Items.Add("Heavy Jets");
                ddlPlaneType.Items.Add("Regional Jets");
                ddlPlaneType.Items.Add("Narrow Body Aircraft");
                ddlPlaneCapacity.Items.Add("Select Capacity");
                for (int i = 200; i <= 1000; i = i + 100)
                {
                    ddlPlaneCapacity.Items.Add(i.ToString());
                }

                long planeId = long.Parse(Session["planeId"].ToString());
                Label1.Text = planeId.ToString();
                plane = dao.GetPlaneDetailsById(planeId);
                txtName.Text = plane.PlaneName;
                txtNo.Text = plane.PlaneNo;
                ddlPlaneType.SelectedValue = plane.PlaneType;
                ddlPlaneCapacity.SelectedValue = plane.PlaneCapacity.ToString();
                txtOwnweFirstName.Text = plane.OwnerFirstName;
                txtOwnweLastName.Text = plane.OwnerLastName;
                txtOwnerNo.Text = plane.OwnerMobile.ToString();
                txtOwnerEmail.Text = plane.OwnerEmail;
            }
        }
    }

    protected void btnUpdatePlane_Click(object sender, EventArgs e)
    {
        long planeId = long.Parse(Session["planeId"].ToString());
        Label1.Text = planeId.ToString();
        plane.PlaneId = planeId;
        plane.PlaneName = txtName.Text;
        plane.PlaneNo = txtNo.Text;
        plane.PlaneType = ddlPlaneType.SelectedValue;
        plane.PlaneCapacity = int.Parse(ddlPlaneCapacity.SelectedValue);
        plane.OwnerFirstName = txtOwnweFirstName.Text;
        plane.OwnerLastName = txtOwnweLastName.Text;
        plane.OwnerMobile = long.Parse(txtOwnerNo.Text);
        plane.OwnerEmail = txtOwnerEmail.Text;
        int result = dao.ModifyPlaneDetails(plane);
        if (result > 0)
        {
            
            Response.Redirect("UpdateSuccess.aspx");
        }
        else
        {
            Response.Write("<script>alert('Plane Details not updated successfully....Try again');window.location.href='UpdatePlane.aspx'</script>");
        }
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("DisplayPlane.aspx");
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }
}