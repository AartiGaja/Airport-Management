﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            Response.Redirect("Admin.aspx");
        }
        if (Session["managerId"] != null)
        {
            Response.Redirect("Manager.aspx");
        }
        if (Session["pilotId"] != null)
        {
            Response.Redirect("Pilot.aspx");
        }

        
    }
    protected void Admin_Submit(object sender, EventArgs e)
    {
        DateTime dt;
        if (!(DateTime.TryParse(TextBox4.Text, out dt)))
        {
            lblDOB0.Text = "Date format should be dd/MM/yyyy";
        }
        else
        {
            lblDOB0.Text = "";
            if (DateTime.Parse(TextBox4.Text) <= DateTime.Now)
            {
                lblDOB.Text = "";
                TimeSpan span = DateTime.Now - DateTime.Parse(TextBox4.Text);
                int age = (DateTime.MinValue + span).Year - 1;
                if (Radio_Male.Checked == false && Radio_female.Checked == false)
                {
                    lblGender.Visible = true;
                }
                int result1 = 0;
                AdminInfoDAO ad = new AdminInfoDAO();
                Admin admin = new Admin();
                admin.FirstName = TextBox1.Text;
                admin.LastName = TextBox8.Text;
                admin.Age = age.ToString();
                if (Radio_Male.Checked == true)
                {
                    Radio_female.Checked = false;
                    admin.Gender = "Male";
                }
                else
                {
                    Radio_Male.Checked = false;
                    admin.Gender = "Female";
                }
                admin.DateOfBirth = TextBox4.Text;
                admin.ContactNumber = long.Parse(TextBox5.Text);
                admin.AlternateContactNumber = long.Parse(TextBox9.Text);
                admin.EmailId = TextBox6.Text;
                admin.Password = TextBox7.Text;
                int resultSsn = ad.CheckEmail(admin.EmailId);
                if (resultSsn == 1)
                {
                    checkEmail.Text = "*Email ID already exits";
                }
                else
                {
                    checkEmail.Text = "";
                    result1++;
                }
                if (Radio_Male.Checked == true || Radio_female.Checked == true)
                {
                    lblGender.Text = "";
                    result1++;
                }
                if (DateUtil.DateUtil.ConvertToDate(TextBox4.Text) < System.DateTime.Now)
                {
                    lblDOB.Text = "";
                    result1++;
                }
                if (result1 == 3)
                {
                    int result = ad.UserRegistration(admin);
                    if (result > 0)
                    {
                        Session["EmailID"] = TextBox6.Text;
                        Response.Write("<script>alert('Registration successful');window.location.href='Initial Selection.aspx'</script");
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
            }
            else
            {
                lblDOB.Text = "*Select Valid DOB";
            }
        }

    }

    protected void Radio_Male_CheckedChanged(object sender, EventArgs e)
    {
        if (Radio_Male.Checked == true)
        {
            Radio_female.Checked = false;
            lblGender.Text = "";
        }
    }

    protected void Radio_female_CheckedChanged(object sender, EventArgs e)
    {
        if (Radio_female.Checked == true)
        {
            Radio_Male.Checked = false;
            lblGender.Text = "";
        }
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Initial Selection.aspx");
    }

 

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminRegistration.aspx");
    }

    protected void TextBox9_TextChanged(object sender, EventArgs e)
    {
        if (TextBox9.Text == TextBox5.Text)
        {
            lblAlternateContactNumber.Text = "*Alternate Contact Number should be Different";
        }
        else
        {
            lblAlternateContactNumber.Text = "";
        }
    }
}