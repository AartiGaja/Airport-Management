﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            ManagerInfoDAO managerDao = new ManagerInfoDAO();
            List<Manager> managerList = managerDao.DisplayActiveManagerList();
            List<string> managerDetailsList = new List<string>();
            foreach (Manager manager in managerList)
            {
                string email;
                email = manager.FirstName + manager.LastName + "/" + manager.EmailId.ToString();
                managerDetailsList.Add(email);
            }
            ddlManagername.DataSource = managerDetailsList;
            ddlManagername.DataBind();
        }

        
        
    }
   

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnAddHangar_Click(object sender, EventArgs e)
    {
        DateTime dt;
        if (!(DateTime.TryParse(txtOccFromDate.Text, out dt)))
        {
            lblOccupancyFromDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else if (!(DateTime.TryParse(txtOccTillDate.Text, out dt)))
        {
            lblOccupancyTillDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else if (!(DateTime.TryParse(txtAvaFromDate.Text, out dt)))
        {
            lblAvailableFromDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else if (!(DateTime.TryParse(txtAvaTillDate.Text, out dt)))
        {
            lblAvailableTillDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else
        {
            int result = 0;
            HangarDAO hangarDao = new HangarDAO();
            Hangar hangar = new Hangar();
            hangar.HangarName = txtHangarName.Text;
            string[] str = ddlManagername.SelectedItem.Text.Split('/');
            hangar.ManagerId = hangarDao.SelectId(str[1]);
            hangar.OccupanyFromDate = DateTime.Parse(txtOccFromDate.Text);
            hangar.OccupanyTillDate = DateTime.Parse(txtOccTillDate.Text);
            hangar.AvailableFromDate = DateTime.Parse(txtAvaFromDate.Text);
            hangar.AvailableTillDate = DateTime.Parse(txtAvaTillDate.Text);
            hangar.Active = "Vacant";

            if (DateTime.Parse(txtOccFromDate.Text) >= DateTime.Parse(txtOccTillDate.Text))
            {
                lblOccupancyTillDate.Text = "'Occupancy till Date' should be greater than 'Occupancy from Date'";
                result++;
            }
            if (DateTime.Parse(txtAvaFromDate.Text) >= DateTime.Parse(txtAvaTillDate.Text))
            {
                lblOccupancyTillDate.Text = "'Available till Date' should be greater than 'Available from Date'";
                result++;
            }
            if (DateTime.Parse(txtOccFromDate.Text) <= DateTime.Parse(txtAvaFromDate.Text) &&
                DateTime.Parse(txtAvaFromDate.Text) <= DateTime.Parse(txtOccTillDate.Text))
            {
                lblAvailableFromDate.Text = "'Available from Date' should not be within 'Occupancy Date'";
                result++;
            }
            if (DateTime.Parse(txtOccFromDate.Text) <= DateTime.Parse(txtAvaTillDate.Text) &&
                DateTime.Parse(txtAvaTillDate.Text) <= DateTime.Parse(txtOccTillDate.Text))
            {
                lblAvailableTillDate.Text = "'Available till Date' should not be within 'Occupancy Date'";
                result++;
            }

            if (result == 0)
            {
                if (hangarDao.AddHangar(hangar) == 0)
                {
                    Response.Write("<script>alert('Hangar name already exists')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Hangar Added successfully');window.location.href='ViewHangar.aspx'</script");
                }
            }
        }
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddHangar.aspx");
    }

}