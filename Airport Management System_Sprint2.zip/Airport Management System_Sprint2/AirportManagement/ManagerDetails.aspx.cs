﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
            if (Session["adminId"] != null)
            {
                lblWelcome.Text = Session["adminId"].ToString();
            }
            else
            {
                Response.Redirect("Initial Selection.aspx");
            }
        if (!IsPostBack)
        {
            DisplayManager();
        }


    }

    protected void DisplayManager()
    {
        try
        {
            Manager manager = new Manager();
            ManagerInfoDAO managerDao = new ManagerInfoDAO();
            List<Manager> managerList = managerDao.DisplayManagerList();
            managerGrid.DataSource = managerList;
            managerGrid.DataBind();
        }
        catch (EmptyException)
        {
            Response.Redirect("EmptyManager.aspx");
        }
    }

    protected void managerEdit(object sender, GridViewEditEventArgs e)
    {
        GridViewRow row = managerGrid.Rows[e.NewEditIndex];
        Session["managerId1"] = row.Cells[0].Text;
        Response.Redirect("UpdateManager.aspx");
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }

    protected void managerGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        DateTime dt;
            if (DateTime.TryParse(e.Row.Cells[5].Text,out dt))
        {
            e.Row.Cells[5].Text = dt.ToString("dd/MM/yyyy");
        }
    }
}