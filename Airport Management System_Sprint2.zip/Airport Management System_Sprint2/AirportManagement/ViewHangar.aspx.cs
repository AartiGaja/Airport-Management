﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            DisplayManager();
        }
    }
    protected void DisplayManager()
    {
        try
        {
            Hangar hangar = new Hangar();
            HangarDAO hangarDao = new HangarDAO();
            List<Hangar> hangarList = hangarDao.DisplayHangar();
            hangarGrid.DataSource = hangarList;
            hangarGrid.DataBind();
        }
        
        catch (EmptyException)
        {
            Response.Redirect("EmptyHangar.aspx");
        }
    }




    protected void HangerEdit(object sender, GridViewEditEventArgs e)
    {
        GridViewRow row = hangarGrid.Rows[e.NewEditIndex];
        Session["hangarId"] = row.Cells[0].Text;

        Response.Redirect("UpdateHangar.aspx");
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }
}
