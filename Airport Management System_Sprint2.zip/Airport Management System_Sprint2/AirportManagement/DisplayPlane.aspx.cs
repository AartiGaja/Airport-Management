﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            DisplayPlane();

        }
    }
    protected void DisplayPlane()
    {
        try
        {
            PlaneDao planeDao = new PlaneDao();
            List<Plane> planeList = planeDao.GetPlaneDetails();
            planeGrid.DataSource = planeList;
            planeGrid.DataBind();
        }
        catch (EmptyException)
        {
            Response.Redirect("PlaneEmpty.aspx");
        }
    }

    protected void planeEdit(object sender, GridViewEditEventArgs e)
    {
        GridViewRow row = planeGrid.Rows[e.NewEditIndex];
        Session["planeId"] = row.Cells[0].Text;
        Response.Redirect("UpdatePlane.aspx");
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }

}