﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["managerId"] != null)
        {
            lblWelcome.Text = Session["managerId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            ddlHangarStatus.Items.Add("Select");
            ddlHangarStatus.Items.Add("occupied");
            ddlHangarStatus.Items.Add("vacant");

            HangarDAO hangarDao = new HangarDAO();
            List<string> hangarList = hangarDao.HangarName();
            ddlHangarName.DataSource = hangarList;
            ddlHangarName.DataBind();

        }
    }

    protected void btnHangarStatus_Click(object sender, EventArgs e)
    {
        Hangar hangar = new Hangar();
        HangarDAO hangarDao = new HangarDAO();
        hangar.HangarName = ddlHangarName.SelectedItem.Text;
        hangar.Status = ddlHangarStatus.SelectedItem.Text;
        hangarDao.UpdateStatus(hangar);
        Response.Write("<script>alert('Hangar Status Updated Successfully');window.location.href='Manager.aspx'</script");
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["managerId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Manager.aspx");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Manager.aspx");
    }

}