﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            DisplayPilot();
        }
    }
    protected void DisplayPilot()
    {
        try
        {
            Pilot pilot = new Pilot();
            PilotInfoDAO pilotDao = new PilotInfoDAO();
            List<Pilot> pilotList = pilotDao.DisplayPilotList();
            pilotGrid.DataSource = pilotList;
            pilotGrid.DataBind();
        }
        catch(EmptyException)
        {
            Response.Redirect("EmptyPilot.aspx");
        }
        
    }

    protected void planeEdit(object sender, GridViewEditEventArgs e)
    {
        GridViewRow row = pilotGrid.Rows[e.NewEditIndex];
        Session["pilotId1"] = row.Cells[0].Text;
        Response.Redirect("UpdatePilot.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void pilotGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        DateTime dt;
        if (DateTime.TryParse(e.Row.Cells[4].Text, out dt))
        {
            e.Row.Cells[4].Text = dt.ToString("dd/MM/yyyy");
        }
    }
}