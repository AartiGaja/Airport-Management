﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;
using DateUtil;

public partial class Default2 : System.Web.UI.Page
{
    FlightPlan flightPlan = new FlightPlan();
    FlightPlanDao planDao = new FlightPlanDao();



    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["pilotId"] != null)
        {
            lblWelcome.Text = Session["pilotId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (Session["Pilot_Id"] == null || Session["pilot_Id"] == null)
        {
            Response.Redirect("Pilot.aspx");
        }
        else
        {
            txtPilot.Text = Session["Pilot_Id"].ToString();
            if (!IsPostBack)
            {
                // int id = flightPlan.FlightId;
                int pilotId = int.Parse(Session["pilot_Id"].ToString());
                int id = int.Parse(Request.QueryString["FlightId"]);
                flightPlan = planDao.getPlaneDetailsById(id);

                string[] cities = { "Chennai", "Delhi", "Kolkata", "Mumbai" };

                ddlArrivalLocation.Items.Add("Select");
                foreach (String city in cities)
                {
                    ddlArrivalLocation.Items.Add(city);
                }



                ddlDepartureLocation.Items.Add("Select");
                foreach (String city in cities)
                {
                    if (ddlArrivalLocation.SelectedValue != city)
                    {
                        ddlDepartureLocation.Items.Add(city);
                    }
                }
                ddlArrivalLocation.SelectedValue = flightPlan.ArrivalLocation;
                ddlDepartureLocation.SelectedValue = flightPlan.DepartureLocation;
                txtArrivalTime.Text = flightPlan.ArrivalTime.ToString("yyyy'-'MM'-'dd'T'HH:mm");
                txtDepartureTime.Text = flightPlan.DepartureTime.ToString("yyyy'-'MM'-'dd'T'HH:mm");

                List<Plane> planeList = planDao.getPlaneDetailsList();
                List<string> pilotDetailsList = new List<string>();
                List<string> planeDetailsList = new List<string>();
                foreach (Plane plane in planeList)
                {
                    string value = plane.PlaneName + "/" + plane.PlaneNo;
                    planeDetailsList.Add(value);
                }
                ddlPlaneDetails.DataSource = planeDetailsList;
                ddlPlaneDetails.DataBind();
                ddlPlaneDetails.SelectedValue = flightPlan.Plane.PlaneName + "/" + flightPlan.Plane.PlaneNo;

            }
        }
    }

    protected void btnAddPlane_Click(object sender, EventArgs e)
    {
        DateTime dt;
        lblDepartureDate1.Text = "";
        lblDepartureDate.Text = "";
        lblArrivalTime0.Text = "";
        if (ddlArrivalLocation.Text == ddlDepartureLocation.Text) 
        {
            lblDepartureDate1.Text = "Arrival and Departure location should be different";
        } 
        else if (!(DateTime.TryParse(txtDepartureTime.Text, out dt)))
        {
            lblDepartureDate.Text = "Departure Date and Time should be in format dd/MM/yyyy hh:mm AM/PM";
        }
        else if (!(DateTime.TryParse(txtArrivalTime.Text, out dt)))
        {
            lblArrivalTime0.Text = "Arrival Date and Time should be in format dd/MM/yyyy hh:mm AM/PM";
        }
        else
        {
            flightPlan.ArrivalLocation = ddlArrivalLocation.Text;
            flightPlan.DepartureLocation = ddlDepartureLocation.Text;
            flightPlan.ArrivalTime = DateUtil1.ConvertToDate(txtArrivalTime.Text);
            flightPlan.DepartureTime = DateUtil1.ConvertToDate(txtDepartureTime.Text);
            flightPlan.FlightId = int.Parse(Request.QueryString["FlightId"]);

            string[] plane = ddlPlaneDetails.Text.Split('/');
            flightPlan.Plane = new Plane();
            flightPlan.Plane.PlaneName = plane[0];
            flightPlan.Plane.PlaneNo = plane[1];
            int res = planDao.modifyFlightInfo(flightPlan);

            lblArrivalTime.Text = "";
            lblDepartureDate0.Text = "";
            lblArrivalTime1.Text = "";

            if (DateTime.Parse(txtArrivalTime.Text) <= DateTime.Parse(txtDepartureTime.Text))
            {
                lblArrivalTime.Text = "'Arrival Date and time' should be greater than 'Departure Date and time'";
            }
            else if (DateTime.Parse(txtDepartureTime.Text) <= System.DateTime.Now)
            {
                lblDepartureDate0.Text = "'Departure Date and time' should be greater than 'current Date and time'";
                lblArrivalTime.Text = "";

            }
            else if (DateTime.Parse(txtArrivalTime.Text) <= System.DateTime.Now)
            {
                lblArrivalTime1.Text = "'Arrival Date and time' should be greater than 'current Date and time'";
                lblArrivalTime.Text = "";
                lblDepartureDate0.Text = "";
            }
            else
            {
                if (res > 0)
                {
                    Response.Write("<script>alert('Schedule Updated Successfully');window.location.href='ViewSchedulePilot.aspx'</script");
                }
            }
        }
    }
    protected void ddlFlightName_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ddlArrivalLocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        string[] cities = { "Chennai", "Delhi", "Kolkata", "Mumbai" };
        foreach (String city in cities)
        {
            if (ddlArrivalLocation.SelectedValue != city)
            {
                ddlDepartureLocation.Items.Add(city);
            }
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["pilotId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Pilot.aspx");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewSchedulePilot.aspx");
    }

}