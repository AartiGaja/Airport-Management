﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack)
        {
            panelAdmin.Visible = false;
            panelManager.Visible = false;
            panelPilot.Visible = false;
            
        }
        if (Session["adminId"] != null)
        {
            Response.Redirect("Admin.aspx");
        }
        if (Session["managerId"] != null)
        {
            Response.Redirect("Manager.aspx");
        }
        if (Session["pilotId"] != null)
        {
            Response.Redirect("Pilot.aspx");
        }
    }



    protected void rdAdmin_CheckedChanged(object sender, EventArgs e)
    {
        if(rdAdmin.Checked==true)
        {
            rdManager.Checked = false;
            rdPilot.Checked = false;
            panelAdmin.Visible = true;
            panelManager.Visible = false;
            panelPilot.Visible = false;
        }
    }

    protected void rdManager_CheckedChanged(object sender, EventArgs e)
    {
        if (rdManager.Checked == true)
        {
            rdAdmin.Checked = false;
            rdPilot.Checked = false;
            panelAdmin.Visible = false;
            panelManager.Visible = true;
            panelPilot.Visible = false;
        }
    }

    protected void rdPilot_CheckedChanged(object sender, EventArgs e)
    {
        if (rdPilot.Checked == true)
        {
            rdAdmin.Checked = false;
            rdManager.Checked = false;
            panelAdmin.Visible = false;
            panelManager.Visible = false;
            panelPilot.Visible = true;
        }
    }

    protected void btnAdmin_Click(object sender, EventArgs e)
    {
        AdminInfoDAO log = new AdminInfoDAO();
        int result = log.AdminLogin(txtAdminmail.Text, txtPwdAdmin.Text);
        if (result > 0)
        {
            Session["adminId"] = log.Username(txtAdminmail.Text);
            Response.Write("<script>alert('Welcome Admin');window.location.href='Admin.aspx'</script");
        }
        else
        {
            Response.Write("<script>alert('Invalid Credentials....Try again')</script>");
           
        }
    }

    protected void btnManager_Click(object sender, EventArgs e)
    {
        ManagerInfoDAO log = new ManagerInfoDAO();
        int result = log.ManagerLogin (txtManagermail.Text, txtPwdManager.Text);
        if (result == 1)
        {
            
            Session["managerId"] = log.Username(txtManagermail.Text);
            Response.Write("<script>alert('Welcome Manager');window.location.href='Manager.aspx'</script");
        }
        if (result == 2)
        {
            Response.Write("<script>alert('User Status Inactive..Try after some time')</script");
            
        }
        if (result == 3)
        {
            Response.Write("<script>alert('Invalid Credential..Try Again')</script");         
            
        }
    }

    protected void btnPilot_Click(object sender, EventArgs e)
    {
        PilotInfoDAO log = new PilotInfoDAO();
        int result = log.pilotLogin(int.Parse(txtPilotSSN.Text), txtPwdPilot.Text);
        if (result == 1)
        {

            Session["pilotId"] = log.Username(int.Parse(txtPilotSSN.Text));
            Session["pilot_Id"] = log.UserId(int.Parse(txtPilotSSN.Text));
            Response.Write("<script>alert('Welcome Pilot');window.location.href='Pilot.aspx'</script");
        }
        if (result == 2)
        {
            Response.Write("<script>alert('User Status Inactive..Try after some time')</script");

        }
        if (result == 3)
        {
            Response.Write("<script>alert('Invalid Credential..Try Again')</script");

        }


    }
}