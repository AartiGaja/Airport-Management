﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["managerId"] != null)
        {
            lblWelcome.Text = Session["managerId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        ViewAllotments();
    }
    public void ViewAllotments()
    {
        try
        {
            Hangar hangar = new Hangar();
            HangarDAO hangarDao = new HangarDAO();
            List<Hangar> hangarList = hangarDao.DisplayAllotments();
            allotGrid.DataSource = hangarList;
            allotGrid.DataBind();
        }
        
        catch (EmptyException)
        {
            Response.Redirect("EmptyAllotment.aspx");
        }
    }


    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["managerId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Manager.aspx");

    }
}