﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.Model;
using Com.Cognizant.Airport.DAO;

public partial class Default2 : System.Web.UI.Page
{
    Manager manager = new Manager();
    ManagerInfoDAO managerDao = new ManagerInfoDAO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }

        if (!IsPostBack)
        {
            if (Session["managerId1"] == null)
            {
                Response.Redirect("Admin.aspx");
            }
            else
            {
                int managerId = int.Parse(Session["managerId1"].ToString());
                Label1.Text = managerId.ToString();
                manager = managerDao.DisplaySpecficUserById(managerId);
                lblFirstName.Text = manager.FirstName;
                lblLastName.Text = manager.LastName;
                lblAge.Text = manager.Age.ToString();
                lblGender.Text = manager.Gender;
                lblDateofBirth.Text = manager.DateOfBirth;
                lblContactNumber.Text = manager.ContactNumber.ToString();
                lblAlternateContactNumber.Text = manager.AlternateContactNumber.ToString();
                lblEmail.Text = manager.EmailId;
                lblAddress.Text = manager.Address;

                if (manager.Active.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }
            }
        }
    }

    protected void btnUpdateManager_Click(object sender, EventArgs e)
    {
        int managerId = int.Parse(Session["managerId1"].ToString());
        Label1.Text = managerId.ToString();
        if (chkActive.Checked == true)
        {
            manager.Active = "Yes";
        }
        else if (chkActive.Checked == false)
        {
            manager.Active = "No";
        }
        string active = manager.Active;
        managerDao.EditManagerInfo(active,managerId);
        Response.Write("<script>alert('Update Successfull');window.location.href='ManagerDetails.aspx'</script");
    }

       protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ManagerDetails.aspx");
    }
}