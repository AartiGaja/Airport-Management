﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;

public partial class _Default : System.Web.UI.Page
{
    Hangar hangar = new Hangar();
    HangarDAO hangarDao = new HangarDAO();
   
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            if(Session["hangarId"]!=null)
            {
                int hangarId = int.Parse(Session["hangarId"].ToString());

                hangar = hangarDao.GetHangarById(hangarId);
                txtHangarName.Text = hangar.HangarName;
                ddlManagername.SelectedValue = hangar.FirstName + " " + hangar.LastName + "/" + hangar.EmailId;
                txtOccFromDate.Text = hangar.OccupanyFromDate.ToString("yyyy'-'MM'-'dd");
                txtOccTillDate.Text = hangar.OccupanyTillDate.ToString("yyyy'-'MM'-'dd");
                txtAvaFromDate.Text = hangar.AvailableFromDate.ToString("yyyy'-'MM'-'dd");
                txtAvaTillDate.Text = hangar.AvailableTillDate.ToString("yyyy'-'MM'-'dd");

                ManagerInfoDAO managerDao = new ManagerInfoDAO();
                List<Manager> managerList = managerDao.DisplayActiveManagerList();
                List<string> managerDetailsList = new List<string>();
                foreach (Manager manager in managerList)
                {
                    string email;
                    email = manager.FirstName + " " + manager.LastName + "/" + manager.EmailId.ToString();
                    managerDetailsList.Add(email);
                }
                ddlManagername.DataSource = managerDetailsList;
                ddlManagername.DataBind();
            }
            else
            {
                Response.Redirect("Admin.aspx");
            }
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnUpdateHangar_Click(object sender, EventArgs e)
    {
        DateTime dt;
        if (!(DateTime.TryParse(txtOccFromDate.Text, out dt)))
        {
            lblOccupancyFromDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else if (!(DateTime.TryParse(txtOccTillDate.Text, out dt)))
        {
            lblOccupancyTillDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else if (!(DateTime.TryParse(txtAvaFromDate.Text, out dt)))
        {
            lblAvailableFromDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else if (!(DateTime.TryParse(txtAvaTillDate.Text, out dt)))
        {
            lblAvailableTillDate0.Text = "Date format should be dd/MM/yyyy";
        }
        else
        {

            int result = 0;
            int hangarId = int.Parse(Session["hangarId"].ToString());
            string[] str = ddlManagername.SelectedItem.Text.Split('/');
            hangar.HangarName = txtHangarName.Text;
            hangar.HangarId = hangarId;
            hangar.ManagerId = hangarDao.SelectId(str[1]);
            hangar.OccupanyFromDate = DateTime.Parse(txtOccFromDate.Text);
            hangar.OccupanyTillDate = DateTime.Parse(txtOccTillDate.Text);
            hangar.AvailableFromDate = DateTime.Parse(txtAvaFromDate.Text);
            hangar.AvailableTillDate = DateTime.Parse(txtAvaTillDate.Text);
            if (DateTime.Parse(txtOccFromDate.Text) >= DateTime.Parse(txtOccTillDate.Text))
            {
                lblOccupancyTillDate.Text = "'Occupancy till Date' should be greater than 'Occupancy from Date'";
                result++;
            }
            if (DateTime.Parse(txtAvaFromDate.Text) >= DateTime.Parse(txtAvaTillDate.Text))
            {
                lblOccupancyTillDate.Text = "'Available till Date' should be greater than 'Available from Date'";
                result++;
            }
            if (DateTime.Parse(txtOccFromDate.Text) <= DateTime.Parse(txtAvaFromDate.Text) &&
                DateTime.Parse(txtAvaFromDate.Text) <= DateTime.Parse(txtOccTillDate.Text))
            {
                lblAvailableFromDate.Text = "'Available from Date' should not be within 'Occupancy Date'";
                result++;
            }
            if (DateTime.Parse(txtOccFromDate.Text) <= DateTime.Parse(txtAvaTillDate.Text) &&
                DateTime.Parse(txtAvaTillDate.Text) <= DateTime.Parse(txtOccTillDate.Text))
            {
                lblAvailableTillDate.Text = "'Available till Date' should not be within 'Occupancy Date'";
                result++;
            }

            if (result == 0)
            {
                hangarDao.EditHangarInfo(hangar);
                Response.Write("<script>alert('Update Successfull');window.location.href='ViewHangar.aspx'</script");
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewHangar.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }
}