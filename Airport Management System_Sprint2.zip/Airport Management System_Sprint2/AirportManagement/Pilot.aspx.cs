﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["pilotId"] != null)
        {
            lblWelcome.Text = Session["pilotId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {

            lblPilotId.Text = Session["Pilot_Id"].ToString();

        }
    }

   

    protected void btnViewSchedule_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewSchedulePilot.aspx");
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["pilotId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Pilot.aspx");

    }
}