﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Airport.DAO;
using Com.Cognizant.Airport.Model;
using DateUtil;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminId"] != null)
        {
            lblWelcome.Text = Session["adminId"].ToString();
        }
        else
        {
            Response.Redirect("Initial Selection.aspx");
        }
        if (!IsPostBack)
        {
            string[] cities = { "Chennai", "Delhi", "Kolkata", "Mumbai" };
            ddlDepartureLocation.Items.Add("Select");
            foreach (String city in cities)
            {
                ddlDepartureLocation.Items.Add(city);
            }
            ddlArrivalLocation.Items.Add("Select");

            FlightPlanDao flightDao = new FlightPlanDao();
            List<Pilot> pilotList = flightDao.getPilotDetails();
            List<Plane> planeList = flightDao.getPlaneDetailsList();


            List<string> pilotDetailsList = new List<string>();
            foreach (Pilot pilot in pilotList)
            {
                string detail;
                detail = pilot.FirstName + " " + pilot.LastName + "/" + pilot.Ssn.ToString();
                pilotDetailsList.Add(detail);
            }
            ddlPilotName.DataSource = pilotDetailsList;
            ddlPilotName.DataBind();

            List<string> planeDetailsList = new List<string>();
            foreach (Plane plane in planeList)
            {
                string value = plane.PlaneName + "/" + plane.PlaneNo;
                planeDetailsList.Add(value);
            }
            ddlPlaneDetails.DataSource = planeDetailsList;
            ddlPlaneDetails.DataBind();
        }


    }


    protected void btnAddPlane_Click(object sender, EventArgs e)
    {
        DateTime dt;
        lblDepartureDate.Text = "";
        lblArrivalTime0.Text = "";
        if (!(DateTime.TryParse(txtDepartureTime.Text, out dt)))
        {
            lblDepartureDate.Text = "Departure Date and Time should be in format dd/MM/yyyy hh:mm AM/PM";
        }
        else if (!(DateTime.TryParse(txtArrivalTime.Text, out dt)))
        {
            lblArrivalTime0.Text = "Arrival Date and Time should be in format dd/MM/yyyy hh:mm AM/PM";
        }
        else
        {
            FlightPlan plan = new FlightPlan();
            FlightPlanDao flightDao = new FlightPlanDao();
            DateTime dateTime = DateUtil.DateUtil1.ConvertToDate(txtArrivalTime.Text);

            string[] ssn = ddlPilotName.SelectedItem.Text.Split('/');
            plan.Ssn = int.Parse(ssn[1]);

            plan.Plane = new Plane();

            string[] planeDetail = ddlPlaneDetails.Text.Split('/');
            plan.Plane.PlaneName = planeDetail[0];
            plan.Plane.PlaneNo = planeDetail[1];

            plan.ArrivalLocation = ddlArrivalLocation.Text;
            plan.DepartureLocation = ddlDepartureLocation.Text;
            plan.ArrivalTime = DateUtil.DateUtil1.ConvertToDate(txtArrivalTime.Text);
            plan.DepartureTime = DateUtil.DateUtil1.ConvertToDate(txtDepartureTime.Text);

            lblArrivalTime.Text = "";
            lblDepartureDate0.Text = "";
            lblArrivalTime1.Text = "";

            if (DateTime.Parse(txtArrivalTime.Text) <= DateTime.Parse(txtDepartureTime.Text))
            {
                lblArrivalTime.Text = "'Arrival Date and time' should be greater than 'Departure Date and time'";
            }
            else if (DateTime.Parse(txtDepartureTime.Text) <= System.DateTime.Now)
            {
                lblDepartureDate0.Text = "'Departure Date and time' should be greater than 'current Date and time'";
                lblArrivalTime.Text = "";

            }
            else if (DateTime.Parse(txtArrivalTime.Text) <= System.DateTime.Now)
            {
                lblArrivalTime1.Text = "'Arrival Date and time' should be greater than 'current Date and time'";
                lblArrivalTime.Text = "";
                lblDepartureDate0.Text = "";
            }
            
            else
            {
                int value = flightDao.addFlightPlanDetails(plan);
                if (value > 0)
                {
                    Response.Redirect("FlightPlanSuccess.aspx");
                }
            }
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["adminId"] = null;
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Initial Selection.aspx");
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");
    }

    protected void ddlDepartureLocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlArrivalLocation.Items.Count == 4)
        {
            ddlArrivalLocation.Items.RemoveAt(1);
            ddlArrivalLocation.Items.RemoveAt(1);
            ddlArrivalLocation.Items.RemoveAt(1);
        }
        string[] cities = { "Chennai", "Delhi", "Kolkata", "Mumbai" };
        foreach (String city in cities)
        {
            if (ddlDepartureLocation.SelectedValue != city)
            {
                ddlArrivalLocation.Items.Add(city);
            }
        }
    }
}