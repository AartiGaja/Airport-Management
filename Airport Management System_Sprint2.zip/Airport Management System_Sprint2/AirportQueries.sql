create database airport;

use airport;


create table [Admin](
Admin_ID bigint IDENTITY(1,1) NOT NULL,
First_Name varchar(50) NOT NULL,
Last_Name varchar(50) NOT NULL,
Age int NOT NULL,
Gender varchar(10) NOT NULL,
DoB date NOT NULL,
Contact_Number bigint NOT NULL,
Alt_Contact_Number bigint NOT NULL,
Email_ID varchar(50) NOT NULL,
Password varchar(15) NOT NULL);

create table Manager(
Manager_ID bigint IDENTITY(1,1) NOT NULL,
First_Name varchar(50) NOT NULL,
Last_Name varchar(50) NOT NULL,
Age int NOT NULL,
Gender varchar(10) NOT NULL,
DoB date NOT NULL,
Contact_Number bigint NOT NULL,
Alt_Contact_Number bigint NOT NULL,
Email_ID varchar(50) NOT NULL,
Password varchar(15) NOT NULL,
Address varchar(200) not null,
Active varchar(5) not null,
constraint[ma_id_pk] primary key(Manager_ID));

create table [Owner](
Owner_ID bigint IDENTITY(1,1) NOT NULL ,
Owner_first_Name varchar(100) not null,
Owner_Last_name varchar(100) not null,
Owner_Contact_number int not null,
Owner_Email varchar(50) not null,
constraint[ow_id_pk] primary key(Owner_ID));

create table Planes(
Plane_ID bigint IDENTITY(1,1) NOT NULL,
Plane_Name varchar(20) not null,
Plane_Type varchar(10) not null,
Plane_capacity int not null,
Owner_Id bigint not null,
constraint [pl_id_pk] primary key(Plane_ID),
constraint[pl_id_fk] foreign key(Owner_Id) references Owner(Owner_ID));

create table [Hangar](
Hangar_ID bigint IDENTITY(1,1) NOT NULL,
Manager_Id bigint not null,
Status varchar(1) not null,
Occupancy_From_date varchar(10) not null,
Occupancy_till_date varchar(10) not null,
Available_from_date varchar(10) not null,
Available_till_date varchar(10) not null,
plane_Id bigint not null,constraint[ha_id_fk] foreign key(Manager_Id) references Manager(Manager_ID),
constraint [ha_pl_id_fk] foreign key(Plane_Id) references Planes(Plane_ID));

create table Pilot(
Pilot_ID bigint IDENTITY(1,1) NOT NULL,
First_Name varchar(50) NOT NULL,
Last_Name varchar(50) NOT NULL,
Gender varchar(10) NOT NULL,
DoB date NOT NULL,
Contact_Number bigint NOT NULL,
License_Number varchar(100) not null,
[Address] varchar(100) not null,
SSN int not null,
password varchar(20) not null,
Active varchar(5) not null,
constraint [pi_id_pk] primary key(Pilot_ID));

create table Schedule(
Schedule_ID bigint IDENTITY(1,1) NOT NULL,
Pilot_Id bigint not null,
Plane_Id bigint not null,
Schedule_Date date not null,
constraint [sc_pi_id_fk] foreign key(Pilot_Id) references Pilot(Pilot_ID),
constraint [sc_pl_id_fk] foreign key(Plane_Id) references Planes(Plane_ID));

create table [Flight Plan](
Flight_ID bigint IDENTITY(1,1) NOT NULL,
Arrival_Location varchar(30) not null,
Departure_Location varchar(30) not null,
Arrival_Time datetime not null,
Departure_Time datetime not null,
Pilot_Id bigint not null,
Plane_Id bigint not null,
constraint [fl_pi_id_fk] foreign key(Pilot_Id) references Pilot(Pilot_ID),
constraint [fl_pl_id_fk] foreign key(Plane_Id) references Planes(Plane_ID));







